/**
 * @file Utils includes various functionality.
 * @author Srdjan Jovanovic
 */

/**
 * @description Returns current date as Number that represents milliseconds since 1 January 1970 UTC.
 * @export
 * @return number
 */
export function getTiming(): number {
  return +new Date();
}
