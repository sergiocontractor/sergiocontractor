/**
 * @file IPC enables communication by passing messages through developer-defined "channels".
 * @author Srdjan Jovanovic
 */

export enum Channel {
  ChangeZoom = 'zoom-changed',
  DisplayDevTools = 'display-dev-tools',
  ExecuteShellCommand = 'execute-shell-command',
  Log = 'logger',
  LogAsync = 'logger-async',
  OpenFile = 'open-file',
  OpenXmlFile = 'open-xml-file',
  SaveFile = 'save-file',
  ToastError = 'toast-error',
  ToastInfo = 'toast-info',
  ToastSuccess = 'toast-success',
  ToastWarning = 'toast-warning',
  TransferCommandLine = 'transfer-command-line',
  TransferDataPayload = 'transfer-data-payload',
}

/**
 * @description Whitelisted channels for general IPC.
 */
export const validRxChannels = ['from-main'];
export const validTxChannels = ['to-main'];

/**
 * @description Returns true if validChannels contains a value that is equal to the channelName,
 * otherwise returns false.
 * @export
 * @param  {string[]} validChannels
 * @param  {string} channelName
 * @return boolean
 */
export function isChannelValid(
  validChannels: string[],
  channelName: string
): boolean {
  return validChannels.includes(channelName);
}
