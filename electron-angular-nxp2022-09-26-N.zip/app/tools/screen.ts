import { screen } from 'electron';

/**
 * @file Screen includes functions for the screen operations.
 * @author Srdjan Jovanovic
 */

/**
 * @descriptiom Retrieves screen size in pixels.
 * @export
 * @return Electron.Size
 */
export default function getScreenSize(): Electron.Size {
  return screen.getPrimaryDisplay().workAreaSize;
}
