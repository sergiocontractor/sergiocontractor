import { LogLevel } from './../../src/app/shared/models/global';
import { ipcMain, BrowserWindow } from 'electron';
import { Channel } from './channels';
import { handleLogger, logger } from './logger';

/**
 * @file IPC (Inter-process communication) includes functions to enable processes communication by
 * passing messages through developer-defined "channels" with the ipcMain and ipcRenderer modules.
 * @author Srdjan Jovanovic
 */

const util = require('util');
const exec = util.promisify(require('child_process').exec);

/**
 * @description Starts listening to channels for ipcMain messages.
 * @export
 * @param  {BrowserWindow} browserWindow
 * @return {void}
 */
export default function startIpcMainListeners(
  browserWindow: BrowserWindow
): void {
  // Display DevTools
  ipcMain.on(Channel.DisplayDevTools, (event, args) => {
    if (browserWindow) {
      browserWindow.webContents.openDevTools();
      //browserWindow.webContents.toggleDevTools();
    }
  });

  // Logging handler
  ipcMain.on(Channel.Log, (event, args) => {
    const [level, data] = args;
    handleLogger(level, data);
  });

  // Executes the command within a shell, buffering any generated output.
  ipcMain.handle(Channel.ExecuteShellCommand, async (event, data) => {
    handleLogger(LogLevel.info, data);
    const [cmd, options] = data;
    return new Promise((resolve, reject) => {
      exec(cmd, options, (err, stdout, stderr) => {
        if (err) {
          reject({ err, stdout, stderr });
        } else {
          resolve({ stdout, stderr });
        }
      });
    });
  });
  /*
    try {
      const [command, options] = data;
      logger.info(`Command: ${command}`);
      const { stdout, stderr } = await exec(command, options);
      logger.info(`stdout: ${stdout}`);
      logger.error(`stderr: ${stderr}`);
    } catch (error) {
      // Should contain code (exit code) and signal (that caused the termination).
      logger.error(error);
    }
    */
}
