import {
  boxesTagNames,
  boxTagNames,
  datasetsTagName,
  findNodeSiblings,
  getHierarchicalPath,
  getParentHierarchicalPath,
  LEVEL_SEPARATOR,
  TreeTagName,
} from '../../shared/utils/tree';
import { ApiService } from './../api/api.service';
import { Injectable } from '@angular/core';
import { XMLNode, XMLNodeList } from '../../shared/models/nodes';
import { BehaviorSubject, Observable } from 'rxjs';
import { isValidTagName } from '../../shared/utils/tree';

@Injectable({
  providedIn: 'root',
})
export class DescoverService {
  public descoverDataTree$: Observable<XMLNodeList>;
  private descoverComponentTree$ = new BehaviorSubject<XMLNodeList>([]);
  private boxesTree = [];

  constructor(private readonly apiService: ApiService) {}

  /**
   * @description Initialization of the service subscribes to descover data tree.
   * @return {void}
   * @memberof DescoverService
   */
  init(): void {
    this.descoverDataTree$ = this.apiService.getDescoverDataTree();
    this.descoverDataTree$.subscribe((descoverDataTree) => {
      //console.log('TREE: Descover Data');
      //console.log(descoverDataTree);

      /**
       * boxesTree: Stores limited boxes data needed for UI tree.
       */
      this.boxesTree = [];
      /**
       * hierarchicalDataTree: Stores the XML parsed descover node. Can be used as a datasource for accessing extended XML properties
       * by matching boxes using the property 'hierarchicalPath' that matches a property name 'id' from 'boxesTree'.
       */
      const hierarchicalDataTree = this.traverseTree(descoverDataTree, 0, 0);

      //console.log('TREE: Boxes');
      //console.log(this.boxesTree);

      const tree = JSON.parse(JSON.stringify(this.boxesTree));
      this.descoverComponentTree$.next(tree);
    });
  }

  /**
   * @description Constructs an array of nodes that matches the DOM.
   * @param  {string} id
   * @param  {string} nodeName
   * @return {void}
   * @memberof DescoverService
   */
  buildBoxes(nodeData): void {
    const { nodeName, id, children = [] } = nodeData;

    const parentHierarchicalPath = getParentHierarchicalPath(id);

    const nodeSiblings = findNodeSiblings(
      this.boxesTree,
      parentHierarchicalPath
    );

    if (nodeSiblings) {
      const parent = nodeSiblings?.find(
        (sibling) => sibling.id === parentHierarchicalPath
      );
      const nodeChildren = parent?.children;
      if (nodeChildren) {
        nodeChildren.push(nodeData);
      } else {
        parent.children = [nodeData];
      }
    } else {
      this.boxesTree.push(nodeData);
    }
  }

  /**
   * @description Returns descover component tree.
   * @return Observable<XMLNodeList>
   * @memberof DescoverService
   */
  getDescoverComponentTree(): Observable<XMLNodeList> {
    return this.descoverComponentTree$;
  }

  /**
   * @description Builds a data tree with hierarchical IDs by visiting every node in the tree.
   * @template T
   * @param  {T} value
   * @param  {number} level
   * @param  {number} [id=0]
   * @param  {string} [hierarchicalPath='0']
   * @return T
   * @memberof DescoverService
   */
  traverseTree<T>(
    value: T,
    level: number,
    id: number = 0,
    hierarchicalPath: string = '0'
  ): T {
    if (typeof value !== 'object' || value === null) {
      return value;
    }
    if (Array.isArray(value)) {
      return this.traverseArray(value, level, id, hierarchicalPath);
    }
    return this.traverseObject(value, level, id, hierarchicalPath);
  }

  /**
   * @description Traverse object data recursivly, iterates over the keys.
   * @template T
   * @param  {T} source
   * @param  {number} level
   * @param  {number} id
   * @param  {string} hierarchicalPath
   * @return T
   * @memberof DescoverService
   */
  traverseObject<T>(
    source: T,
    level: number,
    id: number,
    hierarchicalPath: string
  ): T {
    const result = {} as T;

    Object.keys(source).forEach((key) => {
      const value = source[key as keyof T];

      result[key as keyof T] = this.traverseTree(
        value,
        level,
        id,
        hierarchicalPath
      );
    }, {});

    return result as T;
  }

  /**
   * @description Traverse data array recursivly. Maps the hierarchical index for every box node,
   * plus inserts a box node data into boxesTree by calling buildBoxes.
   * @template T
   * @param  {T} data
   * @param  {number} level
   * @param  {number} id
   * @param  {string} hierarchicalPath
   * @return *
   * @memberof DescoverService
   */
  traverseArray<T extends any[]>(
    data: T,
    level: number,
    id: number,
    hierarchicalPath: string
  ): any {
    return data.map((value) => {
      const tagName = value?.tagName;

      if (isValidTagName(tagName, boxesTagNames)) {
        const nodeName = value?.attributes?.type;
        if (nodeName && isValidTagName(tagName, boxTagNames)) {
          /** HIERARCHICAL ID & Level */
          if (level && hierarchicalPath?.length) {
            const levels = hierarchicalPath.split(LEVEL_SEPARATOR);
            if (levels.length > 1) {
              let levelPosition = levels.length - 2;
              const previousLevel = Number(levels[levelPosition]);
              if (level > previousLevel) {
                levels.splice(levelPosition, 1, level.toString());
              }
              levels.splice(++levelPosition, 1, id.toString());
              hierarchicalPath = levels.join(LEVEL_SEPARATOR);
            } else {
              hierarchicalPath = getHierarchicalPath(id, level);
            }
          } else {
            level = 0;
            hierarchicalPath = getHierarchicalPath(id, level);
          }
          value.hierarchicalPath = hierarchicalPath;
          id++;

          // Find datasets
          const datasets = [];
          const datasetsNode = value?.children?.find(
            (child: XMLNode) => child.tagName === datasetsTagName
          );
          if (datasetsNode) {
            datasets.push(datasetsNode);
          }

          // Insert a node to boxesTree
          const node = {
            nodeName,
            id: hierarchicalPath,
            attributes: value?.attributes,
            children: [],
            datasets,
          };
          this.buildBoxes(node);
        } else {
          /** Set a new level */
          if (tagName === TreeTagName.Boxes) {
            id = 0;
            hierarchicalPath = `${hierarchicalPath}${LEVEL_SEPARATOR}${id}`;
            level++;
          }
        }
      }

      return this.traverseTree(value, level, id, hierarchicalPath);
    });
  }
}
