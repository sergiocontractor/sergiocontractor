import { TestBed } from '@angular/core/testing';

import { DescoverService } from './descover.service';

describe('DescoverService', () => {
  let service: DescoverService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DescoverService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
