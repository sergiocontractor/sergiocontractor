import { Injectable, Type } from '@angular/core';
import { AutocompleteComponent } from '../../components/auto-complete/auto-complete.component';
import { ButtonComponent } from '../../components/button/button.component';
import { CheckBoxComponent } from '../../components/check-box/check-box.component';
import { ContainerComponent } from '../../components/container/container.component';
import { InputFieldComponent } from '../../components/input-field/input-field.component';
import { ListBoxComponent } from '../../components/list-box/list-box.component';
import { RadioButtonComponent } from '../../components/radio-button/radio-button.component';
import { SearchFieldComponent } from '../../components/search-field/search-field.component';
import { ToggleComponent } from '../../components/toggle/toggle.component';

export class ComponentElement {
  constructor(public component: Type<any>, public data: any) {}
}

@Injectable({
  providedIn: 'root',
})
export class ComponentsService {
  constructor() {}

  getComponents() {
    const components = [
      new ComponentElement(ButtonComponent, {}),
      new ComponentElement(CheckBoxComponent, {}),
      new ComponentElement(ContainerComponent, {}),
      new ComponentElement(AutocompleteComponent, {}),
      new ComponentElement(InputFieldComponent, {}),
      new ComponentElement(ListBoxComponent, {}),
      new ComponentElement(RadioButtonComponent, {}),
      new ComponentElement(SearchFieldComponent, {}),
      new ComponentElement(ToggleComponent, {}),
    ];
    return components;
  }
}
