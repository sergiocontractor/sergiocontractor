import { Component, OnInit } from '@angular/core';
import { MatDividerModule } from '@angular/material/divider';

@Component({
  selector: 'app-container',
  standalone: true,
  imports: [MatDividerModule],
  templateUrl: './container.component.html',
  styleUrls: ['./container.component.scss'],
})
export class ContainerComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
