import { Component, OnInit } from '@angular/core';
import { MatRadioModule } from '@angular/material/radio';

@Component({
  selector: 'app-radio-button',
  standalone: true,
  imports: [MatRadioModule],
  templateUrl: './radio-button.component.html',
  styleUrls: ['./radio-button.component.scss']
})
export class RadioButtonComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
