import { LoaderService } from './../../services/loader/loader.service';
import { PrimitivesType } from './../../shared/models/global';
import { Observable, of } from 'rxjs';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import {
  AfterViewChecked,
  AfterViewInit,
  Component,
  DoCheck,
  EventEmitter,
  Input,
  NgZone,
  OnInit,
  Output,
} from '@angular/core';
import {
  MatTreeFlatDataSource,
  MatTreeFlattener,
} from '@angular/material/tree';
import {
  ComponentElement,
  ComponentsService,
} from '../../services/components/components.service';
import { FlatTreeControl } from '@angular/cdk/tree';
import { DescoverService } from '../../services/descover/descover.service';
import { TreeFlatNode, TreeNode } from '../../shared/models/nodes';
import { BenchmarkService } from '../../shared/utils/benchmark';
import { ApiService } from '../../services/api/api.service';
import { mockTree } from '../../shared/mocks/descover-mocks';
import { findNodeSiblings } from '../../shared/utils/tree';
import { castEnabledString as castBoolenStringNumber } from '../../shared/utils/types';

/* eslint no-underscore-dangle: 0 */

@Component({
  selector: 'app-boxes',
  templateUrl: './boxes.component.html',
  styleUrls: ['./boxes.component.scss'],
})
export class BoxesComponent
  implements OnInit, AfterViewChecked, AfterViewInit, DoCheck
{
  @Input() tree = [];
  @Output() payload = new EventEmitter<string>();

  dataTree$: Observable<any>;

  components: ComponentElement[] = [];
  dataSource: MatTreeFlatDataSource<TreeNode, TreeFlatNode>;
  treeControl: FlatTreeControl<TreeFlatNode>;
  treeFlattener: MatTreeFlattener<TreeNode, TreeFlatNode>;

  expandedNodeSet = new Set<string>();
  dragging = false;
  expandTimeout: any;
  expandDelay = 100;
  dragNodeInsertToParent = false;

  private benchmark: BenchmarkService;
  private benchmarkCheck: boolean;
  private isBenchmarkRequsted: boolean;

  constructor(
    private readonly apiService: ApiService,
    private readonly componentService: ComponentsService,
    private readonly descoverService: DescoverService,
    private readonly loaderService: LoaderService,
    private readonly ngZone: NgZone
  ) {
    this.isBenchmarkRequsted = this.apiService.isBenchmarkRequested();
    this.treeFlattener = new MatTreeFlattener(
      this.transformer,
      this._getLevel,
      this._isExpandable,
      this._getChildren
    );
    this.treeControl = new FlatTreeControl<TreeFlatNode>(
      this._getLevel,
      this._isExpandable
    );
    this.dataSource = new MatTreeFlatDataSource(
      this.treeControl,
      this.treeFlattener
    );
  }

  /**
   * @description Displays/Expands a node box, or collapses expandables.
   * @param  {TreeFlatNode} node
   * @return {void}
   * @memberof BoxesComponent
   */
  displayNodeToggle(node: TreeFlatNode): void {
    //console.log(`Node toggle ID: ${node?.id}`);
    this.ngZone.run(() => {
      node.attributes.expand = !node.attributes.expand;
      if (node.expandable) {
        if (node.attributes.expand) {
          this.treeControl.expand(node);
        } else {
          this.treeControl.collapse(node);
        }
      }
    });
  }

  /**
   * @description Start a new benchmark when change detection begins.
   * @return {void}
   * @memberof SubjectComponent
   */
  ngDoCheck(): void {
    /*
    this.ngZone.run(() => {
      if (this.benchmarkCheck) {
        this.benchmark = new BenchmarkService(
          window.api.log,
          'Rendering boxes'
        );
      }
    });
    */
  }

  /**
   * @description When change detection has finished child components created, all *ngIfs evaluated
   * @return {void}
   * @memberof SubjectComponent
   */
  ngAfterViewChecked(): void {
    this.ngZone.run(() => {
      if (this.isBenchmarkRequsted && this.benchmarkCheck) {
        this.benchmarkCheck = false;
        this.benchmark.stop();
        //this.loaderService.hide();
      }
    });
  }

  /**
   * @description When change detection has finished child components created, all *ngIfs evaluated
   * @return {void}
   * @memberof SubjectComponent
   */
  ngAfterViewInit(): void {
    this.ngAfterViewChecked();
  }

  ngOnInit(): void {
    this.dataTree$ = this.descoverService.getDescoverComponentTree();

    this.dataTree$.subscribe((dataTree) => {
      //this.loaderService.show();
      if (this.isBenchmarkRequsted && dataTree?.length) {
        this.benchmarkCheck = true;
        this.benchmark = new BenchmarkService(
          window.api.log,
          'Rendering boxes'
        );
      }

      /** @todo REMOVE: Just for testing purpose, loads a mock instead tree data. */
      if (!dataTree?.length) {
        //dataTree = mockTree;
        //console.log(dataTree);
      }

      this.expandTreeNodes(dataTree);

      /** @todo REMOVE: Just for testing purpose, expands all data nodes in the tree. */
      //this.treeControl.expandAll();
    });

    this.components = this.componentService.getComponents();
  }

  /**
   * @description Can node be expanded.
   * @memberof BoxesComponent
   */
  canExpand = (_: number, node: TreeFlatNode) => node.expandable;

  /**
   * @description Class transformer.
   * @memberof BoxesComponent
   */
  transformer = (node: TreeNode, level: number) =>
    new TreeFlatNode(
      node.id,
      node.nodeName,
      castBoolenStringNumber(node),
      node.datasets,
      !!node?.children?.length,
      level
    );

  /**
   * @description Calls rememberExpandedTreeNodes to persist expand state.
   * The cdkDragDrop event.currentIndex jives with visible nodes.
   * @return TreeNode[]
   * @memberof BoxesComponent
   */
  visibleNodes(): TreeNode[] {
    this.rememberExpandedTreeNodes(this.treeControl, this.expandedNodeSet);
    const result = [];

    function addExpandedChildren(node: TreeNode, expanded: Set<string>) {
      result.push(node);
      if (expanded.has(node.id)) {
        node.children.map((child) => addExpandedChildren(child, expanded));
      }
    }
    this.dataSource.data.forEach((node) => {
      addExpandedChildren(node, this.expandedNodeSet);
    });
    return result;
  }

  /**
   * @description Handle the drop, rearrange the data based on the drop event,
   * then rebuild the tree.
   * @param  {CdkDragDrop<string[]>} event
   * @return
   * @memberof BoxesComponent
   */
  drop(event: CdkDragDrop<string[]>) {
    // ignore drops outside of the tree
    if (!event.isPointerOverContainer) {
      return;
    }

    const visibleNodes = this.visibleNodes();

    // deep clone the data source so we can mutate it
    const changedData = JSON.parse(JSON.stringify(this.dataSource.data));

    // remove the node from its old place
    const node = event.item.data;
    const siblings = findNodeSiblings(changedData, node.id);
    const siblingIndex = siblings.findIndex((n) => n.id === node.id);
    const nodeToInsert: TreeNode = siblings.splice(siblingIndex, 1)[0];

    // determine where to insert the node
    const nodeAtDest = visibleNodes[event.currentIndex];
    if (nodeAtDest.id === nodeToInsert.id) {
      return;
    }

    // determine drop index relative to destination array
    let relativeIndex = event.currentIndex; // default if no parent
    const nodeAtDestFlatNode = this.treeControl.dataNodes.find(
      (dataNode) => nodeAtDest.id === dataNode.id
    );
    const parent = this.getParentNode(nodeAtDestFlatNode);
    if (parent) {
      const parentIndex =
        visibleNodes.findIndex((visibleNode) => visibleNode.id === parent.id) +
        1;
      relativeIndex = event.currentIndex - parentIndex;
    }

    // insert node
    const newSiblings = findNodeSiblings(changedData, nodeAtDest.id);
    // if (!newSiblings) return;
    if (this.dragNodeInsertToParent) {
      const indexOfParent = newSiblings.findIndex(
        (element) => element.id === nodeAtDest.id
      );
      newSiblings[indexOfParent].children.push(nodeToInsert);
    } else {
      newSiblings.splice(relativeIndex, 0, nodeToInsert);
    }

    this.dragNodeInsertToParent = false;

    // rebuild tree with mutated data
    this.expandTreeNodes(changedData);
  }

  /**
   * Experimental - opening tree nodes as you drag over them
   */
  dragStart() {
    this.dragNodeInsertToParent = false;
    this.dragging = true;
  }
  dragEnd() {
    this.dragging = false;
  }
  dragHover(node: TreeFlatNode) {
    // untype the event
    const newEvent: any = event;
    const percentageX = newEvent.offsetX / newEvent.target.clientWidth;
    if (percentageX > 0.25) {
      this.dragNodeInsertToParent = true;
    } else {
      this.dragNodeInsertToParent = false;
    }

    if (this.dragging) {
      clearTimeout(this.expandTimeout);
      this.expandTimeout = setTimeout(() => {
        this.treeControl.expand(node);
      }, this.expandDelay);
    }
  }
  dragHoverEnd() {
    if (this.dragging) {
      clearTimeout(this.expandTimeout);
    }
  }

  /**
   * @description Expand tree nodes.
   * @param  {*} data
   * @return {void}
   * @memberof BoxesComponent
   */
  expandTreeNodes(data: any): void {
    this.rememberExpandedTreeNodes(this.treeControl, this.expandedNodeSet);
    this.dataSource.data = data;
    this.forgetMissingExpandedNodes(this.treeControl, this.expandedNodeSet);
    this.expandNodesById(
      this.treeControl.dataNodes,
      Array.from(this.expandedNodeSet)
    );
  }

  private _getLevel = (node: TreeFlatNode) => node.level;
  private _isExpandable = (node: TreeFlatNode) => node.expandable;
  private _getChildren = (node: TreeNode): Observable<TreeNode[]> =>
    of(node.children);

  /**
   * @description Capture latest expanded state.
   * @private
   * @param  {FlatTreeControl<TreeFlatNode>} treeControl
   * @param  {Set<string>} expandedNodeSet
   * @return {void}
   * @memberof BoxesComponent
   */
  private rememberExpandedTreeNodes(
    treeControl: FlatTreeControl<TreeFlatNode>,
    expandedNodeSet: Set<string>
  ): void {
    if (treeControl.dataNodes) {
      treeControl.dataNodes.forEach((node) => {
        if (treeControl.isExpandable(node) && treeControl.isExpanded(node)) {
          // capture latest expanded state
          expandedNodeSet.add(node.id);
        }
      });
    }
  }

  /**
   * @description If the tree doesn't have the previous node, remove it from the expanded list.
   * @private
   * @param  {FlatTreeControl<TreeFlatNode>} treeControl
   * @param  {Set<string>} expandedNodeSet
   * @return {void}
   * @memberof BoxesComponent
   */
  private forgetMissingExpandedNodes(
    treeControl: FlatTreeControl<TreeFlatNode>,
    expandedNodeSet: Set<string>
  ): void {
    if (treeControl.dataNodes) {
      expandedNodeSet.forEach((nodeId) => {
        // maintain expanded node state
        if (!treeControl.dataNodes.find((n) => n.id === nodeId)) {
          // if the tree doesn't have the previous node, remove it from the expanded list
          expandedNodeSet.delete(nodeId);
        }
      });
    }
  }

  /**
   * @description Expands a node by ID.
   * @private
   * @param  {TreeFlatNode[]} flatNodes
   * @param  {string[]} ids
   * @return
   * @memberof BoxesComponent
   */
  private expandNodesById(flatNodes: TreeFlatNode[], ids: string[]): void {
    if (!flatNodes || flatNodes.length === 0) {
      return;
    }
    const idSet = new Set(ids);
    return flatNodes.forEach((node) => {
      //if (idSet.has(node.id) || node?.attributes?.expand) {
      if (idSet.has(node.id)) {
        this.treeControl.expand(node);
        let parent = this.getParentNode(node);
        while (parent) {
          this.treeControl.expand(parent);
          parent = this.getParentNode(parent);
        }
      }
    });
  }

  /**
   * @description Retrieves a parent node.
   * @private
   * @param  {TreeFlatNode} node
   * @return (TreeFlatNode | null)
   * @memberof BoxesComponent
   */
  private getParentNode(node: TreeFlatNode): TreeFlatNode | null {
    const currentLevel = node.level;
    if (currentLevel < 1) {
      return null;
    }
    const startIndex = this.treeControl.dataNodes.indexOf(node) - 1;
    for (let i = startIndex; i >= 0; i--) {
      const currentNode = this.treeControl.dataNodes[i];
      if (currentNode.level < currentLevel) {
        return currentNode;
      }
    }
    return null;
  }
}
