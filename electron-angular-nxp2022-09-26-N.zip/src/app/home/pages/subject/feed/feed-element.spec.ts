import { FeedElement } from './feed-element';

describe('FeedElement', () => {
  it('should create an instance', () => {
    expect(new FeedElement()).toBeTruthy();
  });
});
