import { BenchmarkService } from '../../../shared/utils/benchmark';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { FlatTreeControl } from '@angular/cdk/tree';
import { Component, Injectable, OnInit } from '@angular/core';
import {
  MatTreeFlatDataSource,
  MatTreeFlattener,
} from '@angular/material/tree';
import { BehaviorSubject, Observable, of } from 'rxjs';
import {
  ComponentElement,
  ComponentsService,
} from '../../../services/components/components.service';

/* eslint no-underscore-dangle: 0 */

/**
 * File node data with nested structure.
 * Each node has a tagName, and a type or a list of children.
 */
export class ComponentNode {
  id: string;
  children: ComponentNode[];
  tagName: string;
  type: any;
}

/** Flat node with expandable and level information */
export class FileFlatNode {
  constructor(
    public expandable: boolean,
    public tagName: string,
    public level: number,
    public type: any,
    public id: string
  ) {}
}

/**
 * The file structure tree data in string. The data could be parsed into a Json object
 */
const TREE_DATA = JSON.stringify({
  applications: {
    calendar: 'app',
    chrome: 'app',
    webstorm: 'app',
  },
  documents: {
    angular: {
      src: {
        compiler: 'ts',
        core: 'ts',
      },
    },
    material2: {
      src: {
        button: 'ts',
        checkbox: 'ts',
        input: 'ts',
      },
    },
  },
  downloads: {
    october: 'pdf',
    november: 'pdf',
    tutorial: 'html',
  },
  pictures: {
    photoBoothLibrary: {
      contents: 'dir',
      pictures: 'dir',
    },
    sun: 'png',
    woods: 'jpg',
  },
});

/**
 * File database, it can build a tree structured Json object from string.
 * Each node in Json object represents a file or a directory. For a file, it has tagName and type.
 * For a directory, it has tagName and children (a list of files or directories).
 * The input will be a json object string, and the output is a list of `ComponentNode` with nested
 * structure.
 */
@Injectable()
export class FileDatabase {
  dataChange = new BehaviorSubject<ComponentNode[]>([]);

  constructor() {
    this.initialize();
  }

  get data(): ComponentNode[] {
    return this.dataChange.value;
  }

  initialize() {
    // Parse the string to json object.
    /*
    const dataObject = JSON.parse(TREE_DATA);
    dataObject.apps = {};

    const appName = `App${1}`;

    dataObject.apps[appName] = {
      applications: {
        calendar: 'app',
        chrome: 'app',
        webstorm: 'app',
      },
      documents: {
        angular: {
          src: {
            compiler: 'ts',
            core: 'ts',
          },
        },
        material2: {
          src: {
            button: 'ts',
            checkbox: 'ts',
            input: 'ts',
          },
        },
      },
      downloads: {
        october: 'pdf',
        november: 'pdf',
        tutorial: 'html',
      },
      pictures: {
        photoBoothLibrary: {
          contents: 'dir',
          pictures: 'dir',
        },
        sun: 'png',
        woods: 'jpg',
      },
    };

    // Build the tree nodes from Json object. The result is a list of `ComponentNode` with nested
    //     file node as children.
    const data = this.buildTree(dataObject, 0);

    // Notify the change.
    this.dataChange.next(data);
    */
    this.dataChange.next([]);
  }

  /**
   * Build the file structure tree. The `value` is the Json object, or a sub-tree of a Json object.
   * The return value is the list of `ComponentNode`.
   */
  buildTree(
    obj: { [key: string]: any },
    level: number,
    parentId: string = '0'
  ): ComponentNode[] {
    return Object.keys(obj).reduce<ComponentNode[]>((accumulator, key, idx) => {
      const value = obj[key];
      const node = new ComponentNode();
      node.tagName = key;
      /**
       * Make sure your node has an id so we can properly rearrange the tree during drag'n'drop.
       * By passing parentId to buildFileTree, it constructs a path of indexes which make
       * it possible find the exact sub-array that the node was grabbed from when dropped.
       */
      node.id = `${parentId}/${idx}`;

      if (value != null) {
        if (typeof value === 'object') {
          node.children = this.buildTree(value, level + 1, node.id);
        } else {
          node.type = value;
        }
      }

      return accumulator.concat(node);
    }, []);
  }
}

@Component({
  selector: 'app-subject',
  templateUrl: './subject.component.html',
  styleUrls: ['./subject.component.scss'],
  providers: [FileDatabase],
})
export class SubjectComponent implements OnInit {
  components: ComponentElement[] = [];
  dataSource: MatTreeFlatDataSource<ComponentNode, FileFlatNode>;
  treeControl: FlatTreeControl<FileFlatNode>;
  treeFlattener: MatTreeFlattener<ComponentNode, FileFlatNode>;

  expandedNodeSet = new Set<string>();
  dragging = false;
  expandTimeout: any;
  expandDelay = 1000;
  dragNodeInsertToParent = false;



  constructor(
    private readonly componentService: ComponentsService,
    database: FileDatabase
  ) {
    /*
    this.treeFlattener = new MatTreeFlattener(
      this.transformer,
      this._getLevel,
      this._isExpandable,
      this._getChildren
    );
    this.treeControl = new FlatTreeControl<FileFlatNode>(
      this._getLevel,
      this._isExpandable
    );
    this.dataSource = new MatTreeFlatDataSource(
      this.treeControl,
      this.treeFlattener
    );
    */

    //database.dataChange.subscribe((data) => this.rebuildTreeForData(data));
    //this.dataSource.data = [];
  }

  hasChild = (_: number, node: FileFlatNode) => node.expandable;

  ngOnInit(): void {
    //this.components = this.componentService.getComponents();
  }

  transformer = (node: ComponentNode, level: number) =>
    new FileFlatNode(!!node.children, node.tagName, level, node.type, node.id);
  /**
   * This constructs an array of nodes that matches the DOM,
   * and calls rememberExpandedTreeNodes to persist expand state
   */
  visibleNodes(): ComponentNode[] {
    this.rememberExpandedTreeNodes(this.treeControl, this.expandedNodeSet);
    const result = [];

    function addExpandedChildren(node: ComponentNode, expanded: Set<string>) {
      result.push(node);
      if (expanded.has(node.id)) {
        node.children.map((child) => addExpandedChildren(child, expanded));
      }
    }
    this.dataSource.data.forEach((node) => {
      addExpandedChildren(node, this.expandedNodeSet);
    });
    return result;
  }

  /**
   * Handle the drop - here we rearrange the data based on the drop event,
   * then rebuild the tree.
   * */
  drop(event: CdkDragDrop<string[]>) {
    // ignore drops outside of the tree
    if (!event.isPointerOverContainer) {
      return;
    }

    // construct a list of visible nodes, this will match the DOM.
    // the cdkDragDrop event.currentIndex jives with visible nodes.
    // it calls rememberExpandedTreeNodes to persist expand state
    const visibleNodes = this.visibleNodes();

    // deep clone the data source so we can mutate it
    const changedData = JSON.parse(JSON.stringify(this.dataSource.data));

    // recursive find function to find siblings of node
    function findNodeSiblings(arr: Array<any>, id: string): Array<any> {
      let result: any[];
      let subResult: any[];
      arr.forEach((item) => {
        if (item.id === id) {
          result = arr;
        } else if (item.children) {
          subResult = findNodeSiblings(item.children, id);
          if (subResult) {
            result = subResult;
          }
        }
      });
      return result;
    }

    // remove the node from its old place
    const node = event.item.data;
    const siblings = findNodeSiblings(changedData, node.id);
    const siblingIndex = siblings.findIndex((n) => n.id === node.id);
    const nodeToInsert: ComponentNode = siblings.splice(siblingIndex, 1)[0];

    // determine where to insert the node
    const nodeAtDest = visibleNodes[event.currentIndex];
    if (nodeAtDest.id === nodeToInsert.id) {
      return;
    }

    // determine drop index relative to destination array
    let relativeIndex = event.currentIndex; // default if no parent
    const nodeAtDestFlatNode = this.treeControl.dataNodes.find(
      (n) => nodeAtDest.id === n.id
    );
    const parent = this.getParentNode(nodeAtDestFlatNode);
    if (parent) {
      const parentIndex = visibleNodes.findIndex((n) => n.id === parent.id) + 1;
      relativeIndex = event.currentIndex - parentIndex;
    }
    // insert node
    const newSiblings = findNodeSiblings(changedData, nodeAtDest.id);
    // if (!newSiblings) return;
    if (this.dragNodeInsertToParent) {
      const indexOfParent = newSiblings.findIndex(
        (element) => element.id === nodeAtDest.id
      );
      newSiblings[indexOfParent].children.push(nodeToInsert);
    } else {
      newSiblings.splice(relativeIndex, 0, nodeToInsert);
    }

    this.dragNodeInsertToParent = false;

    // rebuild tree with mutated data
    this.rebuildTreeForData(changedData);
  }

  /**
   * Experimental - opening tree nodes as you drag over them
   */
  dragStart() {
    this.dragNodeInsertToParent = false;
    this.dragging = true;
  }
  dragEnd() {
    this.dragging = false;
  }
  dragHover(node: FileFlatNode) {
    // untype the event
    const newEvent: any = event;
    const percentageX = newEvent.offsetX / newEvent.target.clientWidth;
    if (percentageX > 0.25) {
      this.dragNodeInsertToParent = true;
    } else {
      this.dragNodeInsertToParent = false;
    }

    if (this.dragging) {
      clearTimeout(this.expandTimeout);
      this.expandTimeout = setTimeout(() => {
        this.treeControl.expand(node);
      }, this.expandDelay);
    }
  }
  dragHoverEnd() {
    if (this.dragging) {
      clearTimeout(this.expandTimeout);
    }
  }

  /**
   * The following methods are for persisting the tree expand state
   * after being rebuilt
   */
  rebuildTreeForData(data: any) {
    this.rememberExpandedTreeNodes(this.treeControl, this.expandedNodeSet);
    this.dataSource.data = data;
    this.forgetMissingExpandedNodes(this.treeControl, this.expandedNodeSet);
    this.expandNodesById(
      this.treeControl.dataNodes,
      Array.from(this.expandedNodeSet)
    );
  }

  private _getLevel = (node: FileFlatNode) => node.level;
  private _isExpandable = (node: FileFlatNode) => node.expandable;
  private _getChildren = (node: ComponentNode): Observable<ComponentNode[]> =>
    of(node.children);

  private rememberExpandedTreeNodes(
    treeControl: FlatTreeControl<FileFlatNode>,
    expandedNodeSet: Set<string>
  ) {
    if (treeControl.dataNodes) {
      treeControl.dataNodes.forEach((node) => {
        if (treeControl.isExpandable(node) && treeControl.isExpanded(node)) {
          // capture latest expanded state
          expandedNodeSet.add(node.id);
        }
      });
    }
  }

  private forgetMissingExpandedNodes(
    treeControl: FlatTreeControl<FileFlatNode>,
    expandedNodeSet: Set<string>
  ) {
    if (treeControl.dataNodes) {
      expandedNodeSet.forEach((nodeId) => {
        // maintain expanded node state
        if (!treeControl.dataNodes.find((n) => n.id === nodeId)) {
          // if the tree doesn't have the previous node, remove it from the expanded list
          expandedNodeSet.delete(nodeId);
        }
      });
    }
  }

  private expandNodesById(flatNodes: FileFlatNode[], ids: string[]) {
    if (!flatNodes || flatNodes.length === 0) {
      return;
    }
    const idSet = new Set(ids);
    return flatNodes.forEach((node) => {
      if (idSet.has(node.id)) {
        this.treeControl.expand(node);
        let parent = this.getParentNode(node);
        while (parent) {
          this.treeControl.expand(parent);
          parent = this.getParentNode(parent);
        }
      }
    });
  }

  private getParentNode(node: FileFlatNode): FileFlatNode | null {
    const currentLevel = node.level;
    if (currentLevel < 1) {
      return null;
    }
    const startIndex = this.treeControl.dataNodes.indexOf(node) - 1;
    for (let i = startIndex; i >= 0; i--) {
      const currentNode = this.treeControl.dataNodes[i];
      if (currentNode.level < currentLevel) {
        return currentNode;
      }
    }
    return null;
  }
}
