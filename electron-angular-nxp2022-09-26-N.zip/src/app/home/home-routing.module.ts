import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home.component';
import { GeneralComponent } from './pages/general/general.component';
import { SubjectComponent } from './pages/subject/subject.component';
import { CompareComponent } from './pages/compare/compare.component';
import { ReferenceComponent } from './pages/reference/reference.component';
import { ReportComponent } from './pages/report/report.component';

const routes: Routes = [
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: 'general',
    component: GeneralComponent
  },
  {
    path: 'subject',
    component: SubjectComponent
  },
  {
    path: 'compare',
    component: CompareComponent
  },
  {
    path: 'reference',
    component: ReferenceComponent
  },
  {
    path: 'report',
    component: ReportComponent
  }
];

@NgModule({
  declarations: [],
  imports: [CommonModule, RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule {}
