/**
 * @description JavaScript commonly used primitives: string, number, and boolean
 */
 export type PrimitivesType = string | number | boolean;

/**
 * @description Logging levels.
 * Can't be imported or shared with Main process.
 */
export enum LogLevel {
  error = 0,
  warn = 1,
  info = 2,
  http = 3,
  verbose = 4,
  debug = 5,
  silly = 6,
}
