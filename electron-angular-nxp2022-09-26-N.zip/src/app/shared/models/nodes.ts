import { PrimitivesType } from './global';

export type TreeNodeAttributes = Record<string, PrimitivesType>;

export interface XMLNode {
  tagName: string;
  attributes: TreeNodeAttributes;
  children: XMLNodeList;
}

export type XMLNodeList = Array<XMLNode | string>;

/**
 * Data node with nested structure.
 * Each node has a tagName that equals to value "box", and a type casted as nodeName.
 */
export class TreeNode {
  id: string;
  nodeName: string;
  attributes: TreeNodeAttributes;
  children: TreeNode[];
  datasets: XMLNode[];
  tagName: string;
}

/** Flat node with expandable and level information */
export class TreeFlatNode {
  constructor(
    public id: string,
    public nodeName: string,
    public attributes: TreeNodeAttributes,
    public datasets: XMLNode[],
    public expandable: boolean,
    public level: number
  ) {}
}
