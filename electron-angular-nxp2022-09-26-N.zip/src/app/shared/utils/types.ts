import { PrimitivesType } from '../models/global';
import { TreeNode } from '../models/nodes';

/**
 * @description Cast 'node.attributes.enabled' property string values ("1" or "0") to booelan true/false.
 * @export
 * @param  {TreeNode} node
 * @return Record<string, PrimitivesType>
 */
export function castEnabledString(
  node: TreeNode
): Record<string, PrimitivesType> {
  return {
    ...node.attributes,
    enabled: !!Number(node?.attributes?.enabled),
    expand: !!Number(node?.attributes?.expand),
  };
}
