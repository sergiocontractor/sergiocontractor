export const mockTree = [
  {
    nodeName: 'circuit',
    id: '1/0',
    attributes: {
      type: 'circuit',
      container: '0',
      showcontent: '1',
      expand: '1',
      enabled: '0',
      flags: '',
    },
    children: [],
    datasets: [
      {
        tagName: 'datasets',
        attributes: {},
        children: [
          {
            tagName: 'dataset',
            attributes: {
              name: 'circuit',
            },
            children: [
              {
                tagName: 'data',
                attributes: {
                  name: 'fw',
                  type: 'string',
                },
                children: ['cadence'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'simu',
                  type: 'string',
                },
                children: ['spectre'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'cosimu',
                  type: 'string',
                },
                children: ['none'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'lib',
                  type: 'string',
                },
                children: [],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'cell',
                  type: 'string',
                },
                children: [],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'view',
                  type: 'string',
                },
                children: [],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'path',
                  type: 'string',
                },
                children: ['/dev/null'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'auto',
                  type: 'bool',
                },
                children: ['1'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'linked',
                  type: 'bool',
                },
                children: ['1'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'abvf',
                  type: 'bool',
                },
                children: ['0'],
              },
            ],
          },
          {
            tagName: 'dataset',
            attributes: {
              name: 'options',
              simu: 'mica',
              cosimu: 'none',
              visible: '0',
            },
            children: [
              {
                tagName: 'data',
                attributes: {
                  name: 'mica.DcvSaveList',
                  type: 'string',
                },
                children: [
                  '{v#* -v#*#* depth=5} {@*#i* *:[0-9]* -@x*.[a-wy-z]*#i* -@x*.[A-WY-Z]*#i* -*#isnoisy depth=5}',
                ],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'mica.DcvAutoConverge',
                  type: 'string',
                },
                children: ['auto'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'architecture',
                  type: 'string',
                },
                children: ['-64'],
              },
            ],
          },
          {
            tagName: 'dataset',
            attributes: {
              name: 'options',
              simu: 'spectre',
              cosimu: 'none',
              visible: '0',
            },
            children: [
              {
                tagName: 'data',
                attributes: {
                  name: 'spectre.DcvSaveList',
                  type: 'string',
                },
                children: ['save=all currents=all subcktprobelvl=5'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'Use_LSF_slots',
                  type: 'string',
                },
                children: ['yes'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'spectreApsOption',
                  type: 'string',
                },
                children: ['+aps'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'spectreMtsOption',
                  type: 'string',
                },
                children: [],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'spectreLicOptions',
                  type: 'string',
                },
                children: ['+lqt 0'],
              },
            ],
          },
          {
            tagName: 'dataset',
            attributes: {
              name: 'models',
              visible: '0',
            },
            children: [
              {
                tagName: 'data',
                attributes: {
                  name: 'useCellSet',
                  type: 'bool',
                },
                children: ['1'],
              },
            ],
          },
        ],
      },
    ],
  },
  {
    nodeName: 'insert',
    id: '1/1',
    attributes: {
      type: 'insert',
      container: '0',
      showcontent: '1',
      expand: '1',
      enabled: '1',
      flags: '',
    },
    children: [],
    datasets: [
      {
        tagName: 'datasets',
        attributes: {},
        children: [
          {
            tagName: 'dataset',
            attributes: {
              name: 'common',
            },
            children: [
              {
                tagName: 'data',
                attributes: {
                  name: 'report',
                  type: 'string',
                },
                children: ['1'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'comment',
                  type: 'string',
                },
                children: ['non cumulative mode On-the-fly netlist alteration'],
              },
            ],
          },
          {
            tagName: 'dataset',
            attributes: {
              name: 'line',
              enabled: '1',
            },
            children: [
              {
                tagName: 'data',
                attributes: {
                  name: 'mode',
                  type: 'enum',
                },
                children: ['inb'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'prefix',
                  type: 'string',
                },
                children: [],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'name',
                  type: 'string',
                },
                children: ['i%i1'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'name',
                  type: 'text',
                },
                children: [
                  '// BJT ECP Oscillator Comment (indicated by //)&amp;#10;simulator lang=spectre&amp;#10;Iee (e 0) isource dc=1mA&amp;#10;Vcc (cc 0) vsource dc=5&amp;#10;Q1 (cc b1 e) npn&amp;#10;Q2 (out b2 e) npn&amp;#10;L1 (cc out) inductor l=1u&amp;#10;C1 (cc out) capacitor c=1p&amp;#10;C2 (out b1) capacitor c=272.7p&amp;#10;C3 (b1 0) capacitor c=3n&amp;#10;C4 (b2 0) capacitor c=3n&amp;#10;R1 (b1 0) resistor r=10k&amp;#10;R2 (b2 0) resistor r=10k&amp;#10;&amp;#10;ic cc=5&amp;#10;&amp;#10;model npn bjt type=npn bf=80 rb=100 vaf=50 cjs=2p tf=0.3n tr=6n cje=3p cjc=2p&amp;#10;//OscResp tran stop=80us maxstep=10ns',
                ],
              },
            ],
          },
          {
            tagName: 'dataset',
            attributes: {
              name: 'line',
              enabled: '1',
            },
            children: [
              {
                tagName: 'data',
                attributes: {
                  name: 'mode',
                  type: 'enum',
                },
                children: ['ic'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'prefix',
                  type: 'string',
                },
                children: [],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'name',
                  type: 'string',
                },
                children: ['i%i2'],
              },
            ],
          },
        ],
      },
    ],
  },
  {
    nodeName: 'setvar',
    id: '1/2',
    attributes: {
      type: 'setvar',
      container: '0',
      showcontent: '1',
      expand: '1',
      enabled: '1',
      flags: '',
    },
    children: [],
    datasets: [
      {
        tagName: 'datasets',
        attributes: {},
        children: [
          {
            tagName: 'dataset',
            attributes: {
              name: 'common',
            },
            children: [
              {
                tagName: 'data',
                attributes: {
                  name: 'report',
                  type: 'string',
                },
                children: ['1'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'comment',
                  type: 'string',
                },
                children: ['Parameters or device casing alteration'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'additional',
                  type: 'string',
                },
                children: [
                  'this one is not part of definition, thus shall be ignored / not displayed',
                ],
              },
            ],
          },
          {
            tagName: 'dataset',
            attributes: {
              name: 'other',
            },
            children: [
              {
                tagName: 'data',
                attributes: {
                  name: 'comment',
                  type: 'string',
                },
                children: [
                  'this one is not part of definition, thus shall be ignored / not displayed',
                ],
              },
            ],
          },
          {
            tagName: 'dataset',
            attributes: {
              name: 'line1',
              blockid: 'line',
              enabled: '1',
            },
            children: [
              {
                tagName: 'data',
                attributes: {
                  name: 'mode',
                  type: 'enum',
                },
                children: ['var'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'name',
                  type: 'string',
                },
                children: ['temp'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'value',
                  type: 'expr',
                },
                children: ['27'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'hl',
                  type: 'expr',
                },
                children: ['1'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'll',
                  type: 'expr',
                },
                children: ['0'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'coding',
                  type: 'enum',
                },
                children: ['binary'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'dummy',
                  type: 'string',
                },
                children: [
                  'this one is not part of definition, thus shall be ignored / not displayed',
                ],
              },
            ],
          },
          {
            tagName: 'dataset',
            attributes: {
              name: 'line2',
              blockid: 'line',
              enabled: '1',
            },
            children: [
              {
                tagName: 'data',
                attributes: {
                  name: 'mode',
                  type: 'enum',
                },
                children: ['var'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'name',
                  type: 'string',
                },
                children: ['temp'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'value',
                  type: 'expr',
                },
                children: ['27'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'hl',
                  type: 'expr',
                },
                children: ['1'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'll',
                  type: 'expr',
                },
                children: ['0'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'coding',
                  type: 'enum',
                },
                children: ['binary'],
              },
            ],
          },
        ],
      },
    ],
  },
  {
    nodeName: 'loop',
    id: '1/3',
    attributes: {
      type: 'loop',
      container: '1',
      showcontent: '1',
      expand: '1',
      enabled: '1',
      flags: 'dist 1',
    },
    children: [
      {
        nodeName: 'analysis',
        id: '1/3/0',
        attributes: {
          type: 'analysis',
          container: '1',
          showcontent: '0',
          expand: '1',
          enabled: '1',
          flags: 'work 1',
        },
        children: [],
        datasets: [
          {
            tagName: 'datasets',
            attributes: {},
            children: [
              {
                tagName: 'dataset',
                attributes: {
                  name: 'general',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'mode',
                      type: 'string',
                    },
                    children: ['TRAN'],
                  },
                ],
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'control',
                  mode: 'TRAN',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'clk_opt',
                      type: 'string',
                    },
                    children: ['OFF'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'errpreset',
                      type: 'string',
                    },
                    children: ['none'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'dynamic_params',
                      type: 'string',
                    },
                    children: ['OFF'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'stepControl',
                      type: 'string',
                    },
                    children: ['autostep'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'sample',
                      type: 'string',
                    },
                    children: ['5n'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'start',
                      type: 'string',
                    },
                    children: [],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'stop',
                      type: 'string',
                    },
                    children: ['80u'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'tranNoise',
                      type: 'string',
                    },
                    children: ['OFF'],
                  },
                ],
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'mica none,TRAN',
                  visible: '1',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'tstep',
                      type: 'string',
                    },
                    children: ['100p'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'PreAnalysisCommand',
                      type: 'string',
                    },
                    children: ['save all depth=3'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'tmax',
                      type: 'string',
                    },
                    children: ['10n'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'AllowMarchingPlot',
                      type: 'string',
                    },
                    children: ['no'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'sourceonly',
                      type: 'string',
                    },
                    children: ['no'],
                  },
                ],
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'VCSMica none,TRAN',
                  visible: '0',
                },
                children: [],
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'spectre none,TRAN',
                  visible: '0',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'annotate',
                      type: 'string',
                    },
                    children: ['status'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'fastbreak',
                      type: 'string',
                    },
                    children: ['no'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'ic',
                      type: 'string',
                    },
                    children: ['all'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'maxiters',
                      type: 'string',
                    },
                    children: ['5'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'ckptperiod',
                      type: 'string',
                    },
                    children: ['1800'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'annotateic',
                      type: 'string',
                    },
                    children: ['no'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'cmin',
                      type: 'string',
                    },
                    children: ['0'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'd2aminstep',
                      type: 'string',
                    },
                    children: ['0'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'fastcross',
                      type: 'string',
                    },
                    children: ['discrete'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'maxstep',
                      type: 'string',
                    },
                    children: ['5n'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'restart',
                      type: 'string',
                    },
                    children: ['yes'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'skipdc',
                      type: 'string',
                    },
                    children: ['no'],
                  },
                ],
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'options',
                  visible: '0',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'COMPAREMODE',
                      type: 'enum',
                    },
                    children: ['default'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'method',
                      type: 'string',
                      enabled: '1',
                    },
                    children: ['gear2only'],
                  },
                ],
              },
            ],
          },
        ],
      },
      {
        nodeName: 'meas:clip',
        id: '1/3/1',
        attributes: {
          type: 'meas:clip',
          container: '0',
          showcontent: '1',
          expand: '1',
          enabled: '1',
          flags: '',
        },
        children: [],
        datasets: [
          {
            tagName: 'datasets',
            attributes: {},
            children: [
              {
                tagName: 'dataset',
                attributes: {
                  name: 'clip',
                  enabled: '1',
                  report: '0',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'name',
                      type: 'string',
                    },
                    children: ['clipped'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'unit',
                      type: 'enum',
                    },
                    children: [],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'dim',
                      type: 'enum',
                    },
                    children: ['vector'],
                  },
                ],
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'common',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'signal',
                      type: 'expr',
                    },
                    children: ['v(v#out)'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'from',
                      type: 'expr',
                    },
                    children: ['31u'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'to',
                      type: 'expr',
                    },
                    children: ['32u'],
                  },
                ],
              },
            ],
          },
        ],
      },
      {
        nodeName: 'meas:crossing',
        id: '1/3/2',
        attributes: {
          type: 'meas:crossing',
          container: '0',
          showcontent: '1',
          expand: '1',
          enabled: '1',
          flags: '',
        },
        children: [],
        datasets: [
          {
            tagName: 'datasets',
            attributes: {},
            children: [
              {
                tagName: 'dataset',
                attributes: {
                  name: 'crossing',
                  enabled: '1',
                  report: '0',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'name',
                      type: 'string',
                    },
                    children: ['outcrossings'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'unit',
                      type: 'enum',
                    },
                    children: [],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'dim',
                      type: 'enum',
                    },
                    children: ['vector'],
                  },
                ],
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'common',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'signal1',
                      type: 'expr',
                    },
                    children: ['clipped'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'signal2',
                      type: 'expr',
                    },
                    children: ['10'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'xy',
                      type: 'expr',
                    },
                    children: [],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'nbcross',
                      type: 'expr',
                    },
                    children: ['1'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'crossType',
                      type: 'expr',
                    },
                    children: ['1'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'delay',
                      type: 'expr',
                    },
                    children: [],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'multiple',
                      type: 'expr',
                    },
                    children: ['1'],
                  },
                ],
              },
            ],
          },
        ],
      },
      {
        nodeName: 'meas:custom',
        id: '1/3/3',
        attributes: {
          type: 'meas:custom',
          container: '0',
          showcontent: '1',
          expand: '1',
          enabled: '1',
          flags: '',
        },
        children: [],
        datasets: [
          {
            tagName: 'datasets',
            attributes: {},
            children: [
              {
                tagName: 'dataset',
                attributes: {
                  name: 'custom',
                  enabled: '1',
                  report: '1',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'name',
                      type: 'string',
                    },
                    children: ['xnb'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'unit',
                      type: 'enum',
                    },
                    children: [],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'dim',
                      type: 'enum',
                    },
                    children: ['vector'],
                  },
                ],
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'common',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'signal',
                      type: 'expr',
                    },
                    children: ['count(outcrossings)'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'versus',
                      type: 'expr',
                    },
                    children: ['0'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'versusid',
                      type: 'expr',
                    },
                    children: [],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'comment',
                      type: 'expr',
                    },
                    children: [],
                  },
                ],
              },
            ],
          },
        ],
      },
      {
        nodeName: 'meas:custom',
        id: '1/3/4',
        attributes: {
          type: 'meas:custom',
          container: '0',
          showcontent: '1',
          expand: '1',
          enabled: '1',
          flags: '',
        },
        children: [],
        datasets: [
          {
            tagName: 'datasets',
            attributes: {},
            children: [
              {
                tagName: 'dataset',
                attributes: {
                  name: 'custom',
                  enabled: '1',
                  report: '1',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'name',
                      type: 'string',
                    },
                    children: ['xnb2'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'unit',
                      type: 'enum',
                    },
                    children: [],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'dim',
                      type: 'enum',
                    },
                    children: ['vector'],
                  },
                ],
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'common',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'signal',
                      type: 'expr',
                    },
                    children: [
                      "count(cross(clip(v(v#out),31u,32u),10,1,1,'','',1))",
                    ],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'versus',
                      type: 'expr',
                    },
                    children: ['0'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'versusid',
                      type: 'expr',
                    },
                    children: [],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'comment',
                      type: 'expr',
                    },
                    children: [],
                  },
                ],
              },
            ],
          },
        ],
      },
      {
        nodeName: 'plot',
        id: '1/3/5',
        attributes: {
          type: 'plot',
          container: '0',
          showcontent: '1',
          expand: '0',
          enabled: '1',
          flags: '',
        },
        children: [],
        datasets: [
          {
            tagName: 'datasets',
            attributes: {},
            children: [
              {
                tagName: 'dataset',
                attributes: {
                  name: 'general',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'type',
                      type: 'enum',
                    },
                    children: ['type line'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'linkid',
                      type: 'expr',
                    },
                    children: [],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'id',
                      type: 'string',
                    },
                    children: ['plot1'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'tool',
                      type: 'string',
                    },
                    children: ['mica'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'tool',
                      type: 'enum',
                    },
                    children: ['auto'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'display',
                      type: 'bool',
                    },
                    children: ['1'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'title',
                      type: 'string',
                    },
                    children: [],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'linkmode',
                      type: 'enum',
                    },
                    children: ['noSpec'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'report',
                      type: 'bool',
                    },
                    children: ['0'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'mode',
                      type: 'enum',
                    },
                    children: ['xygrouped'],
                  },
                ],
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'y1-line',
                  enabled: '1',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'log',
                      type: 'enum',
                    },
                    children: ['lin'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'label',
                      type: 'string',
                    },
                    children: [],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'expr',
                      type: 'expr',
                    },
                    children: ['v(/out)'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'col',
                      type: 'string',
                    },
                    children: ['auto'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'symb',
                      type: 'string',
                    },
                    children: [],
                  },
                ],
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'y2-line',
                  enabled: '1',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'log',
                      type: 'enum',
                    },
                    children: ['lin'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'label',
                      type: 'string',
                    },
                    children: [],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'expr',
                      type: 'expr',
                    },
                    children: ['v(v#out)'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'col',
                      type: 'string',
                    },
                    children: ['auto'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'symb',
                      type: 'string',
                    },
                    children: [],
                  },
                ],
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'options',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'grid',
                      type: 'string',
                    },
                    children: ['none'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'bw',
                      type: 'string',
                    },
                    children: ['0'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'dash',
                      type: 'string',
                    },
                    children: ['0'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'legend',
                      type: 'string',
                    },
                    children: ['1'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'linewidth',
                      type: 'string',
                    },
                    children: ['0'],
                  },
                ],
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'x-line',
                  enabled: '1',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'log',
                      type: 'enum',
                    },
                    children: ['lin'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'label',
                      type: 'string',
                    },
                    children: [],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'expr',
                      type: 'expr',
                    },
                    children: [],
                  },
                ],
              },
            ],
          },
        ],
      },
      {
        nodeName: 'meas:atx',
        id: '1/3/6',
        attributes: {
          type: 'meas:atx',
          container: '0',
          showcontent: '1',
          expand: '1',
          enabled: '1',
          flags: '',
        },
        children: [],
        datasets: [
          {
            tagName: 'datasets',
            attributes: {},
            children: [
              {
                tagName: 'dataset',
                attributes: {
                  name: 'atx',
                  enabled: '1',
                  report: '1',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'name',
                      type: 'string',
                    },
                    children: ['atx_25u'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'unit',
                      type: 'enum',
                    },
                    children: [],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'dim',
                      type: 'enum',
                    },
                    children: ['vector'],
                  },
                ],
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'common',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'signal',
                      type: 'expr',
                    },
                    children: ['v(v#out)'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'x',
                      type: 'expr',
                    },
                    children: ['25u'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'period',
                      type: 'expr',
                    },
                    children: [],
                  },
                ],
              },
            ],
          },
        ],
      },
      {
        nodeName: 'meas:aty',
        id: '1/3/7',
        attributes: {
          type: 'meas:aty',
          container: '0',
          showcontent: '1',
          expand: '1',
          enabled: '1',
          flags: '',
        },
        children: [],
        datasets: [
          {
            tagName: 'datasets',
            attributes: {},
            children: [
              {
                tagName: 'dataset',
                attributes: {
                  name: 'aty',
                  enabled: '1',
                  report: '1',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'name',
                      type: 'string',
                    },
                    children: ['trig'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'unit',
                      type: 'enum',
                    },
                    children: [],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'dim',
                      type: 'enum',
                    },
                    children: ['vector'],
                  },
                ],
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'common',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'signal',
                      type: 'expr',
                    },
                    children: ['v(v#out)'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'threshold',
                      type: 'expr',
                    },
                    children: ['2.5'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'nbcross',
                      type: 'expr',
                    },
                    children: ['1'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'crossType',
                      type: 'expr',
                    },
                    children: ['0'],
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'delay',
                      type: 'expr',
                    },
                    children: [],
                  },
                ],
              },
            ],
          },
        ],
      },
    ],
    datasets: [
      {
        tagName: 'datasets',
        attributes: {},
        children: [
          {
            tagName: 'dataset',
            attributes: {
              name: 'common',
            },
            children: [
              {
                tagName: 'data',
                attributes: {
                  name: 'comment',
                  type: 'string',
                },
                children: ['Loop over variables or device cases'],
              },
            ],
          },
          {
            tagName: 'dataset',
            attributes: {
              name: 'line1',
              blockid: 'line',
              enabled: '1',
            },
            children: [
              {
                tagName: 'data',
                attributes: {
                  name: 'mode',
                  type: 'enum',
                },
                children: ['var'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'name',
                  type: 'expr',
                },
                children: ['toto'],
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'inc',
                  type: 'expr',
                },
                children: ['1 2 3'],
              },
            ],
          },
        ],
      },
    ],
  },
];
