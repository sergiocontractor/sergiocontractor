import { BrowserWindow, dialog } from 'electron';
import * as fs from 'fs';
import * as path from 'path';
import { promises as fsPromises } from 'fs';
import { Channel } from './channels';
import { displayToast, logger } from './logger';
import { getTiming } from './utils';
// TO-DO: How to denote type definition files
// import * as txml from 'txml';
const txml = require('txml');

/**
 * @file File includes function for file operations.
 * @author Srdjan Jovanovic
 */

const moduleTitle = `File`;

export const BENCHMARK_XML_FILE = path.join(
  'C:/projects/Diverse/benchmark_gui/xml',
  'osc_spectre_simple.sheet.xml'
);

/**
 * @description Construct the open file dialog for a file selection.
 * @export
 * @param  {BrowserWindow} browserWindow
 * @return Promise<void>
 */
export async function openFile(browserWindow: BrowserWindow): Promise<void> {
  if (!browserWindow) {
    logger.error('WINDOW NOT DEFINED');
  }

  // Display open file dialog
  const { canceled, filePaths } = await dialog.showOpenDialog({
    filters: [
      { name: 'XML Files', extensions: ['xml'] },
      { name: 'All Files', extensions: ['*'] },
    ],
    properties: ['openFile'],
  });

  if (!canceled && filePaths?.length) {
    processFile(browserWindow, filePaths[0]);
  }
}

/**
 * @description Read a file,, parse it as XML, finally send it using IPC
 * @export
 * @param  {BrowserWindow} browserWindow
 * @param  {string} filePath
 * @return {void}
 */
export async function processFile(
  browserWindow: BrowserWindow,
  filePath: string
) {
  let buffer = undefined;

  const startTime = getTiming();

  if (fs.existsSync(filePath)) {
    logger.info(`TIMING - ${getTiming()} - XML file - opening ${filePath}`);
    try {
      buffer = await fsPromises.readFile(filePath);
    } catch (error) {
      if (error instanceof Error) {
        logger.error(error);
      } else {
        logger.info(error);
      }
    }
    logger.info(
      `TIMING - ${getTiming()} - XML file - finished reading from disk`
    );

    logger.info(`TIMING - ${getTiming()} - XML file - parsing`);
    const data = txml.parse(buffer.toString());
    logger.info(`TIMING - ${getTiming()} - XML file - finished parsing`);

    logger.info(`TIMING - ${getTiming()} - XML file - sending data to ANGULAR`);
    browserWindow.webContents.send(Channel.TransferDataPayload, data);
    logger.info(
      `TIMING - ${getTiming()} - XML file - finished sending data to ANGULAR`
    );
    const endTime = getTiming();

    const lasted = endTime - startTime;

    displayToast(Channel.ToastInfo, browserWindow, [
      `The file was proccessed in ${lasted} milliseconds`,
      moduleTitle,
      { timeOut: 5000 },
    ]);
  } else {
    const message = `File '${filePath}' does not exists`;
    logger.info(message);
    displayToast(Channel.ToastInfo, browserWindow, [
      message,
      moduleTitle,
      { timeOut: 10000 },
    ]);
  }
}
