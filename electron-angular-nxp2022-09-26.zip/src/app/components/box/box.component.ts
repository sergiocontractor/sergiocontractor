import { SharedModule } from './../../shared/shared.module';
import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { AutocompleteComponent } from '../auto-complete/auto-complete.component';

@Component({
  selector: 'app-box',
  standalone: true,
  imports: [
    AutocompleteComponent,
    CommonModule,
    FormsModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatDividerModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
  ],
  templateUrl: './box.component.html',
  styleUrls: ['./box.component.scss'],
})
export class BoxComponent implements OnInit {
  @Input() datasets = [];
  @Input() disable = false;
  @Output() payload = new EventEmitter<string>();

  constructor() {}

  ngOnInit(): void {
  }

  onPayload(event) {
    // Handle the custom payload
  }
}
