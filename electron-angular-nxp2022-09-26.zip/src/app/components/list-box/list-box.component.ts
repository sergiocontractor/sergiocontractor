import { Component, OnInit } from '@angular/core';
import { MatListModule } from '@angular/material/list';

@Component({
  selector: 'app-list-box',
  standalone: true,
  imports: [MatListModule],
  templateUrl: './list-box.component.html',
  styleUrls: ['./list-box.component.scss']
})
export class ListBoxComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
