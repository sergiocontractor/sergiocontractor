import { Observable } from 'rxjs/internal/Observable';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { Injectable, NgZone } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { XMLNode, XMLNodeList } from '../../shared/models/nodes';
import { Channel } from '../../../../app/tools/channels';

const API_SERVICE_TITLE = 'API Service';
/**
 * @description Property key name for finding root element that holds Descover data.
 */
const DESCOVER_ROOT_TAG = 'descover';

/**
 * @description Inter-Process Communication (IPC) in Electron enables processes to communicate by passing messages
 * through developer-defined "channels" with the ipcMain and ipcRenderer modules.
 *
 * @export
 * @class ApiService
 */
@Injectable({
  providedIn: 'root',
})
export class ApiService {
  api = window.api;
  private descoverDataTree$ = new BehaviorSubject<XMLNodeList>([]);
  private benchmark = false;

  constructor(
    private readonly ngZone: NgZone,
    private readonly toastrService: ToastrService
  ) {}

  /**
   * @description Initialize service.
   * @return void
   * @memberof ApiService
   */
  init(): void {
    if (this.api) {
      this.handleCommandLineSwitches();
      this.handleToastNotification();
      this.handleFileProcessing();
    }
  }

  /**
   * @description Returns descover data tree.
   * @return Observable<XMLNodeList>
   * @memberof ApiService
   */
  getDescoverDataTree(): Observable<XMLNodeList> {
    return this.descoverDataTree$;
  }

  /**
   * @description Subscribes to handler for the command line switches.
   * @return void
   * @memberof ApiService
   */
  handleCommandLineSwitches(): void {
    this.api.handleCommandLineSwitches((event, commandLineSwitches) => {
      this.benchmark = commandLineSwitches?.benchmark;
    });
  }

  /**
   * @description Subscribes to file processing events, handles parsed files.
   * @return void
   * @memberof ApiService
   */
  handleFileProcessing(): void {
    this.api.handleDataPayload((event, parsedXML) => {
      const descoverData = parsedXML?.find?.(
        (record: XMLNode) => record?.tagName === DESCOVER_ROOT_TAG
      );

      /** @todo Implement a validator for data nodes */
      const nodes = descoverData?.children;

      if (nodes?.length) {
        this.descoverDataTree$.next(nodes);
      } else {
        this.ngZone.run(() => {
          this.toastrService.warning(
            `File data is invalid, does not contain valid 'descover' tag with data nodes.`,
            API_SERVICE_TITLE
          );
        });
      }
    });
  }

  /**
   * @description Handles success, error, info, warning toast notifications.
   * Take (message, title, ToastConfig) pass an options object to replace any default option.
   * @return void
   * @memberof ApiService
   */
  handleToastNotification(): void {
    this.api.handleToastError((event, data) => {
      this.toastrService.error(...data);
    });
    this.api.handleToastInfo((event, data) => {
      this.toastrService.info(...data);
    });
    this.api.handleToastSuccess((event, data) => {
      this.toastrService.success(...data);
    });
    this.api.handleToastWarning((event, data) => {
      this.toastrService.warning(...data);
    });
  }

  /**
   * @description Returns true if the command line switch benchmark was set
   * @return boolean
   * @memberof ApiService
   */
  isBenchmarkRequested(): boolean {
    return this.benchmark;
  }

  /**
   * @description Send a request to main process for displaying of browser's Dev Tools
   * @return void
   * @memberof ApiService
   */
  openDevTools(): void {
      this.api?.displayDevTools(Channel.DisplayDevTools);
  }
}
