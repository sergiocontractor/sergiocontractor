import { Observable } from 'rxjs/internal/Observable';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';

@Injectable({
  providedIn: 'root',
})
export class LoaderService {
  public readonly loading: Observable<boolean>;
  private loader: BehaviorSubject<boolean>;

  constructor() {
    this.loader = new BehaviorSubject<boolean>(false);
    this.loading = this.loader.asObservable();
  }

  show() {
    this.loader.next(true);
  }

  hide() {
    this.loader.next(false);
  }
}
