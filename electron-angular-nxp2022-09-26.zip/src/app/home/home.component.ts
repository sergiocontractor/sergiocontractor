import { Component, NgZone, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
  selectedTab: number;
  private api = window.api;

  constructor(
    private readonly ngZone: NgZone,
    private readonly router: Router
  ) {}

  ngOnInit(): void {
    this.selectedTab = 1;
  }

  async handleClock() {
    this.ngZone.run(async () => {
      let clockValue = 'clock ?';

      const startTime = +new Date();
      this.api.log(`TIMING - ${startTime} - External call - starting`);
      clockValue = 'updating...';
      const result = await this.api.exec('bash getinfo.sh', {
        cwd: '../mockup/bin',
      });
      const endTime = +new Date();
      const timeDiff = endTime - startTime;
      const stderr = result.stderr.trim();
      const overHead = Math.floor(timeDiff - stderr * 1000);
      window.api.log(
        `TIMING - ${endTime} - External call - finished - stderr: "${stderr}" - overhead: ${overHead}ms`
      );
      clockValue = result.stdout.trim();
    });
  }
}
