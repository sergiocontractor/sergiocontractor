import { DynamicComponentLoaderDirective } from './dynamic-component-loader.directive';

describe('DynamicComponentLoaderDirective', () => {
  it('should create an instance', () => {
    const directive = new DynamicComponentLoaderDirective(null);
    expect(directive).toBeTruthy();
  });
});
