import { IpcWrappers } from '../app/preload';

/* SystemJS module definition */
declare const nodeModule: NodeModule;
interface NodeModule {
  id: string;
}

/**
 * @description Global interface for Window that resolves TypeScript typing issues
 */
declare global {
  interface Window {
    api?: IpcWrappers;
    process: any;
    require: any;
  }
}
