import { currentPlatform } from './tools/platform';
import { app, BrowserWindow } from 'electron';
import * as path from 'path';
import * as fs from 'fs';
import * as url from 'url';
import getScreenSize from './tools/screen';
import setMainMenu from './tools/menu';
import startIpcMainListeners from './tools/ipc';
import enableBrowserZoom from './tools/zoom';
import { isDevelopmentOnWindows } from './tools/logger';
import { handleCommandLineSwitches } from './tools/command-line';

/**
 * @file Electron takes a main file defined in your package.json file and executes it on the start-up.
 * This main file creates application windows which contain rendered web pages and interaction with
 * the native GUI of the operating system.
 * @author Srdjan Jovanovic
 */

/**
 * @description The event 'will-finish-launching'. That will be invoked when the application has finished basic startup.
 */
app.on('will-finish-launching', () => {
  if (currentPlatform === 'LINUX') {
    app.commandLine.appendSwitch('disable-gpu');
    app.commandLine.appendSwitch('no-sandbox');
    app.commandLine.appendSwitch('ignore-certificate-errors');
    app.commandLine.appendSwitch(
      'proxy-pac-url',
      'http://emea.nics.nxp.com:8080/proxy.pac'
    );
  }
});

app.commandLine.appendSwitch('benchmark', 'true');

const ANGULAR_AT_LOCAL_HOST = 'http://localhost:4200';

const args = process.argv.slice(1);
const isAppServed = args.some((val) => val === '--serve');

let mainWindow: BrowserWindow = null;

/**
 * @description Loads Angular Application
 * @param  {BrowserWindow} browserWindow
 * @return {void}
 */
function loadAngularApp(browserWindow: BrowserWindow): void {
  if (isAppServed) {
    const debug = require('electron-debug');
    debug();
    try {
      require('electron-reloader')(module);
    } catch {}
    require('electron-reload')(app.getAppPath(), {
      electron: require(path.join(
        app.getAppPath(),
        'node_modules',
        //'.bin',
        'electron'
      )),
      hardResetMethod: 'exit',
    });
    browserWindow.loadURL(ANGULAR_AT_LOCAL_HOST);
  } else {
    // Path when running electron executable
    let pathIndex = path.join(app.getAppPath(), 'index.html');

    const distPath = path.join(app.getAppPath(), 'dist', 'index.html');
    if (fs.existsSync(distPath)) {
      pathIndex = distPath;
    }

    browserWindow.loadURL(
      url.format({
        pathname: pathIndex,
        protocol: 'file:',
        slashes: true,
      })
    );
  }
}

/**
 * @description Creates the browser window.
 * @return BrowserWindow
 */
function createWindow(): BrowserWindow {
  const size = getScreenSize();
  const offset = 500;

  return new BrowserWindow({
    x: offset,
    y: 0,
    width: 1024,
    height: size.height - offset,
    webPreferences: {
      nodeIntegration: true,
      allowRunningInsecureContent: isAppServed,
      // The preload script will not be loaded if the contextIsolation is set to false
      contextIsolation: true,
      // The preload script enables more secure IPC
      preload: path.join(app.getAppPath(), 'public', 'preload.js'),
      // The preload script will not be loaded if the sandbox is set to true
      sandbox: false,
    },
  });
}

/*
 *  ELECTRON APP INIT
 */
try {
  // 1-st executed
  // This method will be called when Electron has finished
  // initialization and is ready to create browser windows.
  // Some APIs can only be used after this event occurs.
  // 500 ms delay can be added to fix the black background issue while using transparent window.
  // setTimeout(createWindow, 500);
  // More details at https://github.com/electron/electron/issues/15947
  app.on('ready', () => {
    mainWindow = createWindow();
    startIpcMainListeners(mainWindow);
    setMainMenu(mainWindow);
    enableBrowserZoom(mainWindow);
    loadAngularApp(mainWindow);

    // 2-nd executed
    // whenReady() is fulfilled when Electron is initialized.
    // May be used as a convenient alternative to checking app.isReady() and subscribing to 'ready' event
    // if the app is not ready yet.
    app.whenReady().then(() => {
      // 3-rd executed
      // While loading the page, the ready-to-show event will be emitted when the renderer process has rendered the page
      // for the first time if the window has not been shown yet.
      mainWindow.once('ready-to-show', () => {
        handleCommandLineSwitches(mainWindow);

        if (isDevelopmentOnWindows) {
          mainWindow.webContents.openDevTools();
        }

        // Reload roll fix
        mainWindow.webContents.on('did-fail-load', () =>
          loadAngularApp(mainWindow)
        );
      });
    });
  });

  // Quit when all windows are closed.
  app.on('window-all-closed', () => {
    // On OS X it is common for applications and their menu bar
    // to stay active until the user quits explicitly with Cmd + Q
    if (process.platform !== 'darwin') {
      app.quit();
    }
  });

  app.on('activate', () => {
    // On OS X it's common to re-create a window in the app when the
    // dock icon is clicked and there are no other windows open.
    if (mainWindow === null) {
      createWindow();
    }
  });
} catch (error) {
  console.error(`Main initialization: ${error}`);
}

