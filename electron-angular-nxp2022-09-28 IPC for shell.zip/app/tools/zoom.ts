import { BrowserWindow } from 'electron';
import { Channel } from './channels';

/**
 * @file Zoom includes support for the browser integrated zoom functionality.
 * @author Srdjan Jovanovic
 */

export enum ZoomDirection {
  In = 'in',
  Out = 'out',
}

/**
 * @descriptiom Enables the zoom in/out functionality.
 * @export
 * @param  {BrowserWindow} browserWindow
 * @return {void}
 */
export default function enableBrowserZoom(browserWindow: BrowserWindow): void {
  const step = 0.2;
  browserWindow.webContents.setZoomFactor(1.0);

  // Upper Limit is working of 500 %
  browserWindow.webContents.setVisualZoomLevelLimits(1, 5);

  browserWindow.webContents.on(Channel.ChangeZoom, (event, zoomDirection) => {
    const currentZoom = browserWindow.webContents.getZoomFactor();

    // Zoom in/out
    switch (zoomDirection as any) {
      case ZoomDirection.In: {
        browserWindow.webContents.zoomFactor = currentZoom + step;
        break;
      }
      case ZoomDirection.Out: {
        // If reduced below Minimum value throws Error 'zoomFactor', must be a double greater than 0.0
        browserWindow.webContents.zoomFactor = currentZoom - step;
      }
    }
  });
}
