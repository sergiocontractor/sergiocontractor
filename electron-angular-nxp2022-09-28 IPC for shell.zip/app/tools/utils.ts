/**
 * @file Utils includes various functionality.
 * @author Srdjan Jovanovic
 */

/**
 * @description Returns current date as Number that represents milliseconds since 1 January 1970 UTC.
 * @export
 * @return number
 */
export function getTiming(): number {
  return +new Date();
}

/**
 * @description Returns current date as Number that represents milliseconds since 1 January 1970 UTC
 * as a string representation using prefix TIMING -
 * @export
 * @return string
 */
 export function getTimingFormatted(message: string): string {
  return `TIMING - ${getTiming().toString()} ${message}`;
}
