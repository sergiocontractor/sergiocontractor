import { BrowserWindow } from 'electron';
import { app } from 'electron';
import * as path from 'path';
import { Channel } from './channels';
import { processFile, BENCHMARK_XML_FILE } from './file';
import { isDevelopmentOnWindows } from './logger';

/**
 * @file Helper that allows reading and handling the command line arguments that are not in use with Chromium.
 * Most of the existing Chromium switches can be found at https://peter.sh/examples/?/chromium-switches.html.
 * @author Srdjan Jovanovic
 */

export const commandLineSwitches = {
  benchmark: {
    switch: 'benchmark',
    help: 'Activates the benchmarking mode, example: --benchmark',
  },
  debug: {
    switch: 'debug',
    help: 'Activates the debugging mode, example: --debug',
  },
  file: {
    switch: 'file',
    help: 'Process a file on the startup sequence, example: --file=./benchmark.xml',
  },
  help: {
    switch: 'help',
    help: 'Displays help info',
  },
};

/**
 * @description True if the benchmark command-line switch is set.
 */
export const isBenchmark = app.commandLine.getSwitchValue(
  commandLineSwitches.benchmark.switch
)
  ? true
  : false;

/**
 * @description True if debugging command-line switch is set.
 */
export const isDebug = app.commandLine.getSwitchValue(
  commandLineSwitches.debug.switch
);

/**
 * @description Handles reading and action responses on command line arguments that Chromium uses.
 * @export
 * @param  {BrowserWindow} browserWindow
 * @return {void}
 */
export function handleCommandLineSwitches(browserWindow: BrowserWindow): void {
  // File switch instructs file opening and processing on the application startup
  const fileToOpen = app.commandLine.getSwitchValue(
    commandLineSwitches.file.switch
  );
  //if (fileToOpen || isDevelopmentOnWindows) {
  if (fileToOpen) {
    const filePath = path.normalize(
      fileToOpen ? fileToOpen : path.normalize(BENCHMARK_XML_FILE)
    );
    processFile(browserWindow, filePath);
  }

  // Help switch prints switches
  if (app.commandLine.getSwitchValue(commandLineSwitches.help.switch)) {
    for (const switchKey in commandLineSwitches) {
      if ({}.hasOwnProperty.call(commandLineSwitches, switchKey)) {
        console.log(
          `  --${switchKey} `.padEnd(20, '.'),
          ` ${commandLineSwitches[switchKey].help}`
        );
      }
    }
    app.quit();
  }

  // Transfer switches
  browserWindow.webContents.send(Channel.TransferCommandLine, {
    benchmark: isBenchmark,
    debug: isDebug,
    file: fileToOpen,
  });
}
