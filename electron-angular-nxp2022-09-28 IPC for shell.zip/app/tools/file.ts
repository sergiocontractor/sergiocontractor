import { BrowserWindow, dialog } from 'electron';
import * as fs from 'fs';
import * as path from 'path';
import { promises as fsPromises } from 'fs';
import { Channel } from './channels';
import { displayToast, logger } from './logger';
import { getTiming, getTimingFormatted } from './utils';
// TO-DO: How to denote type definition files
// import * as txml from 'txml';
const txml = require('txml');

/**
 * @file File includes function for file operations.
 * @author Srdjan Jovanovic
 */

const moduleTitle = `File`;

export const BENCHMARK_XML_FILE = path.join(
  'C:/projects/Diverse/benchmark_gui/xml',
  'osc_spectre_simple.sheet.xml'
);

/**
 * @description Open a file if filePath argument is present or construct the open file dialog for a file selection.
 * Displays a standard dialog box that prompts the user to open a file.
 * After selecting a file, the XML will be processed and sent to the browser app.
 * @export
 * @param  {BrowserWindow} browserWindow
 * @return Promise<void>
 */
export async function openFile(
  browserWindow: BrowserWindow,
  filePath?: string
): Promise<void> {
  if (!browserWindow) {
    logger.error('Critical Error: WINDOW NOT DEFINED!');
  }

  if (!filePath) {
    // Display open file dialog
    const { canceled, filePaths } = await dialog.showOpenDialog({
      filters: [
        { name: 'XML Files', extensions: ['xml'] },
        { name: 'All Files', extensions: ['*'] },
      ],
      properties: ['openFile'],
    });

    if (canceled) {
      filePath = undefined;
    } else {
      filePath = filePaths[0];
    }
  }

  if (filePath) {
    processFile(browserWindow, filePath);
  }
}

/**
 * @description Read a file, parse it as XML,and  finally send it to UI using IPC.
 * @export
 * @param  {BrowserWindow} browserWindow
 * @param  {string} filePath
 * @return Promise<void>
 */
export async function processFile(
  browserWindow: BrowserWindow,
  filePath: string
): Promise<void> {
  let buffer = undefined;

  const startTime = getTiming();

  if (fs.existsSync(filePath)) {
    logger.info(getTimingFormatted('- XML file - opening ${filePath}'));
    try {
      buffer = await fsPromises.readFile(filePath);
    } catch (error) {
      if (error instanceof Error) {
        logger.error(error);
      } else {
        logger.info(error);
      }
    }
    logger.info(getTimingFormatted('- XML file - finished reading from disk'));

    logger.info(getTimingFormatted('- XML file - parsing'));
    const data = txml.parse(buffer.toString());
    logger.info(getTimingFormatted('- XML file - finished parsing'));

    logger.info(getTimingFormatted('- XML file - sending data to ANGULAR app'));
    browserWindow.webContents.send(Channel.TransferDataPayload, data);
    logger.info(
      getTimingFormatted('- XML file - finished sending data to ANGULAR app')
    );

    const endTime = getTiming();

    const lasted = endTime - startTime;

    displayToast(Channel.ToastInfo, browserWindow, [
      `The file was proccessed in ${lasted} milliseconds`,
      moduleTitle,
      { timeOut: 5000 },
    ]);
  } else {
    const message = `File '${filePath}' does not exists`;
    logger.info(message);
    displayToast(Channel.ToastInfo, browserWindow, [
      message,
      moduleTitle,
      { timeOut: 10000 },
    ]);
  }
}
