/**
 * @file menu includes functions for main menu definitions.
 * @author Srdjan Jovanovic
 */
import { Menu, BrowserWindow } from 'electron';
import { openFile } from './file';

export default function setMainMenu(browserWindow: BrowserWindow) {
  Menu.setApplicationMenu(
    Menu.buildFromTemplate([
      {
        label: 'File',
        submenu: [
          {
            label: '&Open',
            accelerator: 'CmdOrCtrl+O',
            click() {
              openFile(browserWindow);
            },
          },
          {
            type: 'separator',
          },
          {
            role: 'quit',
          },
        ],
      },

      {
        label: 'Edit',
        submenu: [
          {
            role: 'undo',
          },
          {
            role: 'redo',
          },
          {
            type: 'separator',
          },
          {
            role: 'cut',
          },
          {
            role: 'copy',
          },
          {
            role: 'paste',
          },
          {
            role: 'selectAll',
          },
        ],
      },

      {
        label: 'View',
        submenu: [
          {
            role: 'reload',
          },
          {
            role: 'forceReload',
          },
          {
            role: 'toggleDevTools',
          },
          {
            type: 'separator',
          },
          {
            role: 'resetZoom',
          },
          {
            role: 'zoomIn',
          },
          {
            role: 'zoomOut',
          },
          {
            type: 'separator',
          },
          {
            role: 'togglefullscreen',
          },
        ],
      },

      {
        role: 'window',
        submenu: [
          {
            role: 'minimize',
          },
          {
            role: 'close',
          },
        ],
      },

      {
        role: 'help',
        submenu: [
          {
            role: 'about',
          },
        ],
      },
    ])
  );
}
