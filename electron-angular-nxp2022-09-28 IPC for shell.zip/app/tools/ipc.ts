import { ipcMain, BrowserWindow } from 'electron';
import { Channel } from './channels';
import { handleLogger, LogLevel } from './logger';
import { openFile } from './file';
import { ExecOptions, spawn, SpawnOptions } from 'child_process';

/**
 * @file IPC (Inter-process communication) includes functions to enable processes communication by
 * passing messages through developer-defined "channels" with the ipcMain and ipcRenderer modules.
 * @author Srdjan Jovanovic
 */

const util = require('util');
const exec = util.promisify(require('child_process').exec);

/**
 * @description Starts listening to channels for ipcMain messages.
 * @export
 * @param  {BrowserWindow} browserWindow
 * @return {void}
 */
export default function startIpcMainListeners(
  browserWindow: BrowserWindow
): void {
  // Display DevTools
  ipcMain.on(Channel.DisplayDevTools, (event, args) => {
    if (browserWindow) {
      browserWindow.webContents.openDevTools();
    }
  });

  // Logging handler
  ipcMain.on(Channel.Log, (event, args) => {
    const [level, data] = args;
    handleLogger(level, data);
  });

  // Toggle DevTools
  ipcMain.on(Channel.ToggleDevTools, (event, args) => {
    if (browserWindow) {
      browserWindow.webContents.toggleDevTools();
    }
  });

  // Open a file
  ipcMain.on(Channel.OpenXmlFile, (event, args) => {
    if (browserWindow) {
      if (Array.isArray(args)) {
        args = args[0];
      }
      openFile(browserWindow, args);
    }
  });

  ipcMain.handle(Channel.ExecuteShellCommand, serviceExecRun);
  ipcMain.handle(Channel.ExecuteShellStream, serviceExecStream);

  // Executes the command within a shell, buffering any generated output.
  /*
  ipcMain.handle(Channel.ExecuteShellCommand, async (event, data) => {
    const [cmd, options] = data;
    return new Promise((resolve, reject) => {
      exec(cmd, options, (err, stdout, stderr) => {
        if (err) {
          reject({ err, stdout, stderr });
        } else {
          resolve({ stdout, stderr });
        }
      });
    });
  });
  */

  /*
    try {
      const [command, options] = data;
      logger.info(`Command: ${command}`);
      const { stdout, stderr } = await exec(command, options);
      logger.info(`stdout: ${stdout}`);
      logger.error(`stderr: ${stderr}`);
    } catch (error) {
      // Should contain code (exit code) and signal (that caused the termination).
      logger.error(error);
    }
    */
}

// Thomas implementation
// Runs a shell command on the host
function serviceExecRun(
  _: any,
  cmd: string,
  options: ExecOptions
): Promise<{ stdout: string; stderr: string }> {
  return new Promise((resolve, reject) => {
    exec(cmd, options, (err, stdout, stderr) => {
      if (err) {
        reject({ err, stdout, stderr });
      } else {
        resolve({ stdout, stderr });
      }
    });
  });
}

// Runs a shell command on the host
function serviceExecStream(
  _: any,
  cmd: string,
  args: string[],
  name: string,
  options: SpawnOptions,
  browserWindow: BrowserWindow
) {
  // console.log(`will run: ${cmd}, with options:`, JSON.stringify(options));
  const proc = spawn(cmd, args, options);

  proc.stdout.on('data', (data) => {
    // console.log(`stream ${name}: stdout: ${data}`);
    browserWindow.webContents.send('exec:streamOut', name, data);
  });

  proc.stderr.on('data', (data) => {
    // console.log(`stream ${name}: stderr: ${data}`);
    browserWindow.webContents.send('exec:streamErr', name, data);
  });

  proc.on('close', () => {
    // console.log(`stream ${name}: close`);
    browserWindow.webContents.send('exec:streamClose', name);
  });
}
