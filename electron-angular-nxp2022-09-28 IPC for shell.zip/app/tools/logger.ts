import { startWith } from 'rxjs/operators';
/**
 * @file Logger includes functions for the logging with Winstons's support for multiple transports.
 * @author Srdjan Jovanovic
 */
import { app, BrowserWindow } from 'electron';
import { createLogger, format, transports } from 'winston';
import { Channel } from './channels';
import { isDebug } from './command-line';
import { currentPlatform } from './platform';

/**
 * @decription Logging levels in Winston conform to the severity ordering specified by RFC5424.
 * @export
 * @enum {number}
 */
export enum LogLevel {
  error = 0,
  warn = 1,
  info = 2,
  http = 3,
  verbose = 4,
  debug = 5,
  silly = 6,
}

/**
 * @description Channels used to display the info.
 */
export type InfoChannels =
  | Channel.ToastError
  | Channel.ToastInfo
  | Channel.ToastSuccess
  | Channel.ToastWarning;

/**
 * @description Returns true if the app is packaged, false otherwise. Can be used to distinguish development and production environments.
 */
export const isProduction = app.isPackaged;

/**
 * @description True if a current running platform is WINDOWS and  the process environmet is not in Production mode.
 */
export const isDevelopmentOnWindows =
  currentPlatform === 'WINDOWS' && !isProduction;

/**
 * @description Renders a toast message.
 * Example of arg = [`Parsed XML data sent to Angular App`, 'File service', { timeOut: 15000 }];
 * @export
 * @param  {InfoChannels} channel
 * @param  {BrowserWindow} browserWindow
 * @return {void}
 */
export function displayToast(
  channel: InfoChannels,
  browserWindow: BrowserWindow,
  toastArguments: [message?: string, title?: string, override?: object]
): void {
  browserWindow.webContents.send(channel, toastArguments);
}

/**
 * @description Logs data based on level.
 * @export
 * @param  {LogLevel} level
 * @param  {*} data
 * @return {void}
 */
export function handleLogger(level: LogLevel, data: any): void {
  switch (level) {
    case LogLevel.error:
      logger.error(data);
      break;
    case LogLevel.warn:
      logger.warn(data);
      break;
    case LogLevel.info:
      logger.info(data);
      break;
    case LogLevel.http:
      logger.http(data);
      break;
    case LogLevel.verbose:
      logger.verbose(data);
      break;
    case LogLevel.debug:
      logger.debug(data);
      break;
    case LogLevel.silly:
      logger.silly(data);
      break;
    default:
      logger.error(`Logging level "${level}" not supported`);
  }
}

/**
 * @description Initial logger options.
 */
export const loggerOptions = {
  file: {
    filename: `logs/electron-angular-app.log`,
    handleExceptions: isProduction,
    maxsize: 5242880, // 5MB
    maxFiles: 3,
    format: format.combine(format.timestamp(), format.json(), format.splat()),
  },
  console: {
    handleExceptions: false,
    format: format.combine(
      format.colorize(),
      format.prettyPrint(),
      format.printf((info) => {
        const message =
          typeof info.message === 'object'
            ? JSON.stringify(info.message, null, 2)
            : info.message;
        return `${info.timestamp} ${info.level}: ${message}`;
      })
    ),
  },
};

/**
 * @description Creates Default Logger.
 */
export const logger = createLogger({
  level: isDebug ? 'info' : 'debug',
  format: format.combine(format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' })),
  transports: [new transports.Console(loggerOptions.console)],
});

// Enable logging to a file functionality if debugging is requested.
if (isDebug) {
  logger.add(new transports.File(loggerOptions.file));
  logger.info(`Electron running on: ${currentPlatform}`);
}
