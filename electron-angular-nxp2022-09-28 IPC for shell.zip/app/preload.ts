import { contextBridge, ipcRenderer } from 'electron';
import {
  Channel,
  isChannelValid,
  validRxChannels,
  validTxChannels,
} from './tools/channels';

/** @file Creates a safe, bi-directional, synchronous bridge across isolated contexts.
 * Context isolation is an Electron feature that allows developers to run code in preload scripts and in Electro APIs
 * in a dedicated JS context. In practice that means that global objects cannot be modified by scripts running in the
 * renderer process.
 */

/**
 * @description IPC wrapper methods
 * @export
 * @interface IpcAPIWrapper
 */
export interface IpcWrappers {
  /** Display browser's DevTools for debugging */
  displayDevTools: (...arg: any) => void;
  toggleDevTools: (...arg: any) => void;
  /** Electron ipcRenderer wrapper of send method */
  electronIpcSend: (channel: string, ...arg: any) => void;
  /** Electron ipcRenderer wrapper of sendSync method */
  electronIpcSendSync: (channel: string, ...arg: any) => any;
  /** Electron ipcRenderer wrapper of invoke method */
  electronIpcInvoke: (channel: string, ...arg: any) => void;
  /** Electron ipcRenderer wrapper of on method */
  electronIpcOn: (
    channel: string,
    listener: (event: any, ...arg: any) => void
  ) => void;
  /** Electron ipcRenderer wrapper of onOnce method */
  electronIpcOnce: (
    channel: string,
    listener: (event: any, ...arg: any) => void
  ) => void;
  /** Electron ipcRenderer wrapper of removeListener method */
  electronIpcRemoveListener: (
    channel: string,
    listener: (event: any, arg: any) => void
  ) => void;
  /** Electron ipcRenderer wrapper of removeAllListeners method */
  electronIpcRemoveAllListeners: (channel: string) => void;
  /** Handle command line switches */
  handleCommandLineSwitches: (
    listener: (event: any, ...arg: any) => void
  ) => void;
  /** Handle Data payload from a file */
  handleXMLData: (listener: (event: any, ...arg: any) => void) => void;
  /** Handle a Toast Notifications */
  handleToastError: (listener: (event: any, ...arg: any) => void) => void;
  handleToastInfo: (listener: (event: any, ...arg: any) => void) => void;
  handleToastSuccess: (listener: (event: any, ...arg: any) => void) => void;
  handleToastWarning: (listener: (event: any, ...arg: any) => void) => void;
  /** Log a message */
  log: (...arg: any) => void;
  /** Log async message */
  logInvoke: (...arg: any) => Promise<any>;
  /** Open a file if the arg is present or display the open file dialog, process XML file after a file is selected */
  openXml: (...arg: any) => void;
  /** Log async message */
  executeShellCommand: (...arg: any) => Promise<any>;

  // Exec
  execRun: (cmd: string, options: any) => any;
  execStream: (cmd: string, args: string[], name: string, options: any) => any;

  // Setup the renederer methods that can be called by main process ("actions")
  eventExecStreamOut: (callback: any) => any;
  eventExecStreamErr: (callback: any) => any;
  eventExecStreamClose: (callback: any) => any;
}

/**
 * @description Exposes API protected methods that allows the renderer process to use
 * the ipcRenderer without exposing the entire object.
 */
contextBridge.exposeInMainWorld('api', {
  displayDevTools: (...arg: any) => {
    ipcRenderer.send(Channel.DisplayDevTools, arg);
  },
  toggleDevTools: (...arg: any) => {
    ipcRenderer.send(Channel.ToggleDevTools, arg);
  },
  electronIpcSend: (channel: string, ...arg: any) => {
    if (isChannelValid(validTxChannels, channel)) {
      ipcRenderer.send(channel, arg);
    }
  },
  electronIpcSendSync: (channel: string, ...arg: any) =>
    ipcRenderer.sendSync(channel, arg),
  electronIpcInvoke: (channel: string, ...arg: any): Promise<any> => {
    if (isChannelValid(validTxChannels, channel)) {
      return ipcRenderer.invoke(channel, arg);
    }
  },
  electronIpcOn: (
    channel: string,
    listener: (event: any, ...arg: any) => void
  ) => {
    if (isChannelValid(validRxChannels, channel)) {
      ipcRenderer.on(channel, listener);
    }
  },
  electronIpcOnce: (
    channel: string,
    listener: (event: any, ...arg: any) => void
  ) => {
    if (isChannelValid(validRxChannels, channel)) {
      ipcRenderer.once(channel, listener);
    }
  },
  electronIpcRemoveListener: (
    channel: string,
    listener: (event: any, ...arg: any) => void
  ) => {
    ipcRenderer.removeListener(channel, listener);
  },
  electronIpcRemoveAllListeners: (channel: string) => {
    ipcRenderer.removeAllListeners(channel);
  },
  // Data sending
  handleCommandLineSwitches: (listener: (event: any, ...arg: any) => void) =>
    ipcRenderer.on(Channel.TransferCommandLine, listener),
  handleXMLData: (listener: (event: any, ...arg: any) => void) =>
    ipcRenderer.on(Channel.TransferDataPayload, listener),
  // Toast messaging
  handleToastError: (listener: (event: any, ...arg: any) => void) =>
    ipcRenderer.on(Channel.ToastError, listener),
  handleToastInfo: (listener: (event: any, ...arg: any) => void) =>
    ipcRenderer.on(Channel.ToastInfo, listener),
  handleToastSuccess: (listener: (event: any, ...arg: any) => void) =>
    ipcRenderer.on(Channel.ToastSuccess, listener),
  handleToastWarning: (listener: (event: any, ...arg: any) => void) =>
    ipcRenderer.on(Channel.ToastWarning, listener),
  // Logging
  log: (...arg: any) => {
    ipcRenderer.send(Channel.Log, arg);
  },
  logInvoke: (...arg: any): Promise<any> =>
    ipcRenderer.invoke(Channel.LogAsync, arg),
  // File operations
  openXml: (...arg: any): void => {
    ipcRenderer.send(Channel.OpenXmlFile, arg);
  },
  // System calls
  executeShellCommand: (...arg: any): Promise<any> =>
    ipcRenderer.invoke(Channel.ExecuteShellCommand, arg),

  // Exec
  execRun: (cmd: string, options = {}) =>
    ipcRenderer.invoke(Channel.ExecuteShellCommand, cmd, options),
  execStream: (cmd: string, args: string[], name: string, options = {}) =>
    ipcRenderer.invoke(Channel.ExecuteShellStream, cmd, args, name, options),

  // Setup the renederer methods that can be called by main process ("actions")
  eventExecStreamOut: (callback: any) =>
    ipcRenderer.on('exec:streamOut', callback),
  eventExecStreamErr: (callback: any) =>
    ipcRenderer.on('exec:streamErr', callback),
  eventExecStreamClose: (callback: any) =>
    ipcRenderer.on('exec:streamClose', callback),
});
