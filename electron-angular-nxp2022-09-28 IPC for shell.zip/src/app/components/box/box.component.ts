import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { SharedModule } from './../../shared/shared.module';
import { CommonModule } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
} from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { AutocompleteComponent } from '../auto-complete/auto-complete.component';
import { TreeFlatNode, XMLNodeUid } from '../../shared/models/tree';

@Component({
  selector: '[app-box]',
  standalone: true,
  imports: [
    AutocompleteComponent,
    CommonModule,
    FormsModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatDividerModule,
    MatSlideToggleModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
  ],
  templateUrl: './box.component.html',
  styleUrls: ['./box.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BoxComponent implements OnInit {
  @Input() node: TreeFlatNode;
  @Input() disable = false;
  @Output() payload = new EventEmitter<string>();

  constructor() {}

  ngOnInit(): void {}

  trackByUid(index: number, data: XMLNodeUid): number {
    return data.uid;
  }
}
