import { ApiService } from './../../services/api/api.service';
import { MatDividerModule } from '@angular/material/divider';
import { Component, Input, OnInit } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-no-data',
  standalone: true,
  imports: [MatButtonModule, MatDividerModule],
  templateUrl: './no-data.component.html',
  styleUrls: ['./no-data.component.scss'],
})
export class NoDataComponent implements OnInit {
  @Input() message: string;

  constructor(private readonly apiService: ApiService) {}

  /**
   * @description A callback method that is invoked immediately after the default change detector has checked
   * the directive's data-bound properties for the first time, and before any of the view or content children
   * have been checked. It is invoked only once when the directive is instantiated.
   * @return {void}
   * @memberof NoDataComponent
   */
  ngOnInit(): void {
    //
  }

  /**
   * @description Displays a standard dialog box that prompts the user to open a file.
   * After selecting the file, the XML will be processed and rendered.
   * @return {void}
   * @memberof NoDataComponent
   */
  openFile(): void {
    this.apiService.openXmlFile('');
  }
}
