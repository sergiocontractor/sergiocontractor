import { SharedModule } from './../../shared/shared.module';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { CommonModule } from '@angular/common';
import { MatInputModule } from '@angular/material/input';

@Component({
  selector: 'app-autocomplete',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatAutocompleteModule,
    MatFormFieldModule,
    MatInputModule,
    ReactiveFormsModule,
    SharedModule,
  ],
  templateUrl: './auto-complete.component.html',
  styleUrls: ['./auto-complete.component.scss'],
})
export class AutocompleteComponent implements OnInit {
  @Input() ariaLabel: string;
  @Input() disable = false;
  @Input() label: string;
  @Input() options: string[] = [];
  @Input() placeHolder: string;
  @Input() value: string;
  @Output() payload = new EventEmitter<string>();
  autocompleteControl = new FormControl();
  setOfOptions: Observable<string[]>;

  constructor() {}

  ngOnInit() {
    if (!this.options.length) {
      this.options = Array.isArray(this.value) ? this.value : [this.value ?? ''];
    }
    this.setOfOptions = this.autocompleteControl.valueChanges.pipe(
      startWith(this.value ?? ''),
      map((value) => (value ? this.filterData(value) : this.options.slice()))
    );
  }

  displayData(data: string): string | undefined {
    return data ? data : undefined;
  }

  onDataChange(data: string) {
    //
  }

  /**
   * @description Updates the output payload by emitting an event containing a value
   * @param value
   * @returns void
   */
  updatePayload(value: string): void {
    this.payload.emit(value);
  }

  /**
   * @description Return filtered options by value
   * @param value
   * @returns string[]
   */
  private filterData(value: string): string[] {
    return this.options.filter(
      (option) => option.toLowerCase().indexOf(value.toLocaleLowerCase()) === 0
    );
  }
}
