import {
  Overlay,
  OverlayConfig,
  OverlayModule,
  OverlayRef,
} from '@angular/cdk/overlay';
import {
  Component,
  OnInit,
  TemplateRef,
  ViewChild,
  ViewContainerRef,
} from '@angular/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { Observable } from 'rxjs/internal/Observable';
import { LoaderService } from '../../services/loader/loader.service';
import { OverlayService } from '../../services/overlay/overlay.service';

@Component({
  selector: 'app-loading-spinner',
  standalone: true,
  imports: [MatProgressSpinnerModule, OverlayModule],
  templateUrl: './loading-spinner.component.html',
  styleUrls: ['./loading-spinner.component.scss'],
})
export class LoadingSpinnerComponent implements OnInit {
  loading$: Observable<any>;

  color = 'primary';
  mode = 'indeterminate';
  value = 50;
  displayProgressSpinner = false;
  spinnerWithoutBackdrop = false;

  @ViewChild('loadingSpinnerRef')
  private progressSpinnerRef: TemplateRef<any>;
  private overlayRef: OverlayRef;
  private loadingSpinnerOverlayConfig: OverlayConfig;

  constructor(
    private loaderService: LoaderService,
    private overlayService: OverlayService,
    private viewContainerRef: ViewContainerRef
  ) {}

  /**
   * @description A callback method that is invoked immediately after the default change detector has checked
   * the directive's data-bound properties for the first time, and before any of the view or content children
   * have been checked. It is invoked only once when the directive is instantiated.
   */
  ngOnInit(): void {
    this.loadingSpinnerOverlayConfig = {
      hasBackdrop: true,
    };

    this.loadingSpinnerOverlayConfig.positionStrategy =
      this.overlayService.getGloballyCentered();

    this.overlayRef = this.overlayService.createOverlay(
      this.loadingSpinnerOverlayConfig
    );

    this.loading$ = this.loaderService.getLoadingStatus();
    this.loading$.subscribe((loading: boolean) => {
      this.displayProgressSpinner = loading;
    });
  }

  /**
   * @description Based on status of displayProgressSpinner attach/detach overlay to progress spinner template.
   * @return {void}
   * @memberof LoadingSpinnerComponent
   */
  ngDoCheck(): void {
    if (this.displayProgressSpinner && !this.overlayRef.hasAttached()) {
      this.overlayService.attachTemplatePortal(
        this.overlayRef,
        this.progressSpinnerRef,
        this.viewContainerRef
      );
    } else if (!this.displayProgressSpinner && this.overlayRef.hasAttached()) {
      this.overlayRef.detach();
    }
  }
}
