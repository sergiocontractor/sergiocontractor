import { ApiService } from './../services/api/api.service';
import { Component, NgZone, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
  selectedTab: number;
  clock;

  constructor(public apiService: ApiService, private readonly ngZone: NgZone) {}

  ngOnInit(): void {
    this.selectedTab = 1;
  }

  async handleClock() {
    this.clock = await this.apiService.execCmd();
  }
}
