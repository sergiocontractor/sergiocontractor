import { LoaderService } from '../../../../services/loader/loader.service';
import { Component, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { DynamicComponentLoaderDirective } from '../../../../shared/directives/dynamic/dynamic-component-loader.directive';
import { ComponentElement } from '../../../../services/components/components.service';

// AdComponent
export interface FeedComponentInterface {
  data: any;
}

@Component({
  selector: 'app-feed',
  templateUrl: './feed.component.html',
  styleUrls: ['./feed.component.scss'],
})
export class FeedComponent implements OnInit, OnDestroy {
  @Input() components: ComponentElement[] = [];

  @ViewChild(DynamicComponentLoaderDirective, { static: true })
  dynamicHost!: DynamicComponentLoaderDirective;

  currentComponentIndex = -1;

  interval: any;

  constructor(private readonly loaderService: LoaderService) {}

  ngOnInit(): void {
    /*
    this.loaderService.show();
    this.loadComponents();
    //this.getAdditionalComponents();
    this.loaderService.hide();
    */
  }

  ngOnDestroy(): void {
    // clearInterval(this.interval);
  }

  getAdditionalComponents(): void {
    /*
    this.interval = setInterval(() => {
      this.loadComponents();
    }, 3000000);
    */
  }

  loadComponents() {
    /*
    this.currentComponentIndex =
      (this.currentComponentIndex + 1) % this.components.length;
    //const feedComponent = this.components[this.currentComponentIndex];

    for (let index = 1; index <= 100; index++) {
      for (const component of this.components) {
        const feedComponent = component;

        const viewContainerRef = this.dynamicHost.viewContainerRef;
        //viewContainerRef.clear();

        const componentRef =
          viewContainerRef.createComponent<FeedComponentInterface>(
            feedComponent.component
          );
        componentRef.instance.data = feedComponent.data;
      }
    }
    */
  }

  eventClick() {
    /*
    this.loadComponents();
    */
  }
}
