import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import {
  ComponentElement,
  ComponentsService,
} from '../../../services/components/components.service';
import { DescoverService } from '../../../services/descover/descover.service';
import { LoaderService } from '../../../services/loader/loader.service';
import { mockTree } from '../../../shared/mocks/descover-mocks';
import { TreeNode } from '../../../shared/models/tree';

/* eslint no-underscore-dangle: 0 */

@Component({
  selector: 'app-subject',
  templateUrl: './subject.component.html',
  styleUrls: ['./subject.component.scss'],
  providers: [],
})
export class SubjectComponent implements OnInit {
  components: ComponentElement[] = [];
  tree: TreeNode[] = [];

  dataTree$: Observable<any>;

  constructor(
    private readonly componentService: ComponentsService,
    private readonly descoverService: DescoverService,
    private readonly loaderService: LoaderService
  ) {}

  ngOnInit(): void {
    //this.components = this.componentService.getComponents();

    this.dataTree$ = this.descoverService.getDescoverComponentTree();
    this.dataTree$.subscribe((dataTree: TreeNode[]) => {
      /** @todo REMOVE: Just for testing purpose, loads a mock instead tree data. */
      if (!dataTree?.length) {
        //dataTree = mockTree;
      }

      this.tree = dataTree;
    });
  }
}
