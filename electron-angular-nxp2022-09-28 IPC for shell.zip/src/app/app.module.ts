import { BoxComponent } from './components/box/box.component';
import { BrowserAnimationsModule, NoopAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { CoreModule } from './core/core.module';

import { AppRoutingModule } from './app-routing.module';

// Material
import { MatNativeDateModule } from '@angular/material/core';
import { MaterialModule } from './material.module';
import { MAT_FORM_FIELD_DEFAULT_OPTIONS } from '@angular/material/form-field';

// NG Translate
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';

import { HomeModule } from './home/home.module';

import { AppComponent } from './app.component';
import { FeedComponent } from './home/pages/subject/feed/feed.component';
import { HomeComponent } from './home/home.component';
import { GeneralComponent } from './home/pages/general/general.component';

import { CompareComponent } from './home/pages/compare/compare.component';
import { ReferenceComponent } from './home/pages/reference/reference.component';
import { ReportComponent } from './home/pages/report/report.component';
import { SubjectComponent } from './home/pages/subject/subject.component';
import { ToastrModule } from 'ngx-toastr';
import { SharedModule } from './shared/shared.module';
import { BoxesComponent } from './components/boxes/boxes.component';
import { NoDataComponent } from './components/no-data/no-data.component';
import { LoadingSpinnerComponent } from './components/loading-spinner/loading-spinner.component';

// AoT requires an exported function for factories
const httpLoaderFactory = (http: HttpClient): TranslateHttpLoader =>
  new TranslateHttpLoader(http, './assets/i18n/', '.json');

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    CompareComponent,
    GeneralComponent,
    ReferenceComponent,
    ReportComponent,
    SubjectComponent,

    BoxesComponent,
  ],
  imports: [
    // Standalone components
    BoxComponent,
    LoadingSpinnerComponent,
    NoDataComponent,

    // Enable animations
    //BrowserAnimationsModule,
    //Disable animations
    NoopAnimationsModule,

    // Modules
    BrowserModule,
    HttpClientModule,
    CoreModule,
    HomeModule,
    AppRoutingModule,
    MatNativeDateModule,
    MaterialModule,
    SharedModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: httpLoaderFactory,
        deps: [HttpClient],
      },
    }),
    ToastrModule.forRoot({
      closeButton: true,
      positionClass: 'toast-bottom-right',
      preventDuplicates: true,
      timeOut: 5000,
    }),
  ],
  providers: [
    {
      provide: MAT_FORM_FIELD_DEFAULT_OPTIONS,
      useValue: { appearance: 'fill' },
    },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
