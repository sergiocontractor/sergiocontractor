import { Component, HostBinding, OnInit } from '@angular/core';
import { ElectronService } from './core/services';
import { TranslateService } from '@ngx-translate/core';
import {
  NavigationCancel,
  NavigationEnd,
  NavigationError,
  NavigationStart,
  Router,
  RouterEvent,
} from '@angular/router';
import { ApiService } from './services/api/api.service';
import { ToastrService } from 'ngx-toastr';
import { DescoverService } from './services/descover/descover.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
  // To disable animations
  @HostBinding('@.disabled')
  public animationsDisabled = true; // Set to true to disable animations

  public showOverlay = true;

  constructor(
    private readonly apiService: ApiService,
    private readonly descoverService: DescoverService,
    private readonly electronService: ElectronService,
    private readonly router: Router,
    private readonly toastrService: ToastrService,
    private readonly translate: TranslateService
  ) {
    this.translate.setDefaultLang('en');

    router.events.subscribe((event: RouterEvent) => {
      this.navigationInterceptor(event);
    });
  }

  ngOnInit() {
    // INIT APP Services
    this.apiService.init();
    this.descoverService.init();
  }

  // Shows and hides the loading spinner during RouterEvent changes
  navigationInterceptor(event: RouterEvent): void {
    if (event instanceof NavigationStart) {
      this.showOverlay = true;
    }
    if (event instanceof NavigationEnd) {
      this.showOverlay = false;
    }

    // Set loading state to false in both of the below events to hide the spinner in case a request fails
    if (event instanceof NavigationCancel) {
      this.showOverlay = false;
    }
    if (event instanceof NavigationError) {
      this.showOverlay = false;
    }
  }
}
