import {
  Overlay,
  OverlayConfig,
  OverlayRef,
  PositionStrategy,
} from '@angular/cdk/overlay';
import { TemplatePortal } from '@angular/cdk/portal';
import { Injectable, TemplateRef, ViewContainerRef } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class OverlayService {
  constructor(private overlay: Overlay) {}

  /**
   * @description Create a new overlay.
   * @param  {OverlayConfig} config
   * @return OverlayRef
   * @memberof OverlayService
   */
  createOverlay(config: OverlayConfig): OverlayRef {
    return this.overlay.create(config);
  }

  /**
   * @description Link references.
   * @param  {OverlayRef} overlayRef
   * @param  {TemplateRef<any>} templateRef
   * @param  {ViewContainerRef} vcRef
   * @return {void}
   * @memberof OverlayService
   */
  attachTemplatePortal(
    overlayRef: OverlayRef,
    templateRef: TemplateRef<any>,
    viewContainerRef: ViewContainerRef
  ): void {
    overlayRef.attach(new TemplatePortal(templateRef, viewContainerRef));
  }

  /**
   * @description Returns a position that is globally centered
   * @return PositionStrategy
   * @memberof OverlayService
   */
  getGloballyCentered(): PositionStrategy {
    return this.overlay
      .position()
      .global()
      .centerHorizontally()
      .centerVertically();
  }
}
