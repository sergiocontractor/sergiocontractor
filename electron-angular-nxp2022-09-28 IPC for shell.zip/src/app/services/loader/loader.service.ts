import { Observable } from 'rxjs/internal/Observable';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';

@Injectable({
  providedIn: 'root',
})
export class LoaderService {
  public readonly loading: Observable<boolean>;
  private loader$ = new BehaviorSubject<boolean>(false);

  constructor() {
    //this.loading = this.getLoadingStatus();
  }

  getLoadingStatus(): Observable<boolean> {
    return this.loader$;
  }

  show() {
    this.loader$.next(true);
  }

  hide() {
    this.loader$.next(false);
  }
}
