import { LoaderService } from './../loader/loader.service';
import { Observable } from 'rxjs/internal/Observable';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { Injectable, NgZone } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { XMLNode, XMLNodeList } from '../../shared/models/nodes';

const API_SERVICE_TITLE = 'API Service';
/**
 * @description Property key name for finding root element that holds Descover data.
 */
const DESCOVER_ROOT_TAG = 'descover';

/**
 * @description Inter-Process Communication (IPC) in Electron enables processes to communicate by passing messages
 * through developer-defined "channels" with the ipcMain and ipcRenderer modules.
 *
 * @export
 * @class ApiService
 */
@Injectable({
  providedIn: 'root',
})
export class ApiService {
  private api = window.api;
  private descoverDataTree$ = new BehaviorSubject<XMLNodeList>([]);
  private benchmark = true;

  constructor(
    private readonly loaderService: LoaderService,
    private readonly ngZone: NgZone,
    private readonly toastrService: ToastrService
  ) {}

  /**
   * @description Initialize service.
   * @return void
   * @memberof ApiService
   */
  init(): void {
    if (this.api) {
      this.handleCommandLineSwitches();
      this.handleToastNotification();
      this.handleFileProcessing();
    }
  }

  /**
   * @description Returns descover data tree.
   * @return Observable<XMLNodeList>
   * @memberof ApiService
   */
  getDescoverDataTree(): Observable<XMLNodeList> {
    return this.descoverDataTree$;
  }

  /**
   * @description Subscribes to handler for the command line switches.
   * @return void
   * @memberof ApiService
   */
  handleCommandLineSwitches(): void {
    this.api.handleCommandLineSwitches((event, commandLineSwitches) => {
      //window.api.log(LogLevel.info, commandLineSwitches);
      //this.benchmark = commandLineSwitches?.benchmark;
    });
  }

  /**
   * @description Subscribes to file processing events, handles parsed files.
   * @return void
   * @memberof ApiService
   */
  handleFileProcessing(): void {
    this.api.handleXMLData((event, parsedXML) => {
      this.ngZone.run(() => {
        this.loaderService.show();
      });

      const descoverData = parsedXML?.find?.(
        (record: XMLNode) => record?.tagName === DESCOVER_ROOT_TAG
      );

      /** @todo Implement a validator for data nodes */
      const nodes = descoverData?.children;

      if (nodes?.length) {
        this.descoverDataTree$.next(nodes);
      } else {
        this.ngZone.run(() => {
          this.toastrService.warning(
            `File data is invalid, does not contain valid 'descover' tag with data nodes.`,
            API_SERVICE_TITLE
          );
        });
      }
    });
  }

  /**
   * @description Handles success, error, info, warning toast notifications.
   * Take (message, title, ToastConfig) pass an options object to replace any default option.
   * @return void
   * @memberof ApiService
   */
  handleToastNotification(): void {
    this.api.handleToastError((event, data) => {
      this.ngZone.run(() => {
        this.toastrService.error(...data);
      });
    });
    this.api.handleToastInfo((event, data) => {
      this.ngZone.run(() => {
        this.toastrService.info(...data);
      });
    });
    this.api.handleToastSuccess((event, data) => {
      this.ngZone.run(() => {
        this.toastrService.success(...data);
      });
    });
    this.api.handleToastWarning((event, data) => {
      this.ngZone.run(() => {
        this.toastrService.warning(...data);
      });
    });
  }

  async execCmd() {
    // Demo for simple external process call
    let clockValue = 'clock ?'; //Display a value
    clockValue = 'updating...';
    const cmd = 'bash getinfo.sh';
    const startTime = +new Date();
    window.api.log(`TIMING - ${startTime} - External call - starting: ${cmd}`);
    const result = await window.api.execRun(cmd, { cwd: './resources' });
    const stderr = result.stderr.trim();
    const endTime = +new Date();
    const timeDiff = endTime - startTime;
    const overHead = Math.floor(timeDiff - stderr * 1000);
    window.api.log(
      `TIMING - ${endTime} - External call - finished - stderr: "${stderr}" - overhead: ${overHead}ms`
    );
    clockValue = result.stdout.trim();
    return clockValue;
  }

  //SHELL
  execShell() {
    // Demo for streamed external process call
    let streamValues: Record<string, string> = { counter: 'stream ?' }; // Display a value
    async function handleStream() {
      window.api.execStream('bash', ['getmanyinfo.sh'], 'counter', {
        cwd: './resources',
      });
    }
    window.api.eventExecStreamOut((_: any, name: string, data: Uint8Array) => {
      const value = new TextDecoder().decode(data);
      streamValues = Object.assign(streamValues, { [name]: value });
    });
    window.api.eventExecStreamErr((_: any, name: string, data: Uint8Array) => {
      const value = new TextDecoder().decode(data);
      streamValues = Object.assign(streamValues, { [name]: '!' + value });
    });
    window.api.eventExecStreamClose((_: any, name: string) => {
      streamValues[name] = 'closed';
    });
  }

  /**
   * @description Returns true if the command line switch benchmark was set
   * @return boolean
   * @memberof ApiService
   */
  isBenchmarkRequested(): boolean {
    return this.benchmark;
  }

  /**
   * @description Send a request to main process for displaying of browser's Dev Tools
   * @return void
   * @memberof ApiService
   */
  openDevTools(): void {
    this.api.displayDevTools();
  }

  /**
   * @description Send a request to main process for a file opening and XML parsing procedure
   * @param  {string} filePath
   * @return {void}
   * @memberof ApiService
   */
  openXmlFile(filePath: string): void {
    this.api.openXml(filePath);
  }
}
