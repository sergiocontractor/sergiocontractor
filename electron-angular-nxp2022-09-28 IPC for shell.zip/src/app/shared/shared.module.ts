import { PropagationClickStopDirective } from './directives/propagation-stop/propagation-stop.directive';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TranslateModule } from '@ngx-translate/core';

import { PageNotFoundComponent } from './components/';
import { WebviewDirective } from './directives/';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DynamicComponentLoaderDirective } from './directives/dynamic/dynamic-component-loader.directive';
import { DisableControlDirective } from './directives/disable-control/disable-control.directive';

@NgModule({
  declarations: [
    PageNotFoundComponent,
    DisableControlDirective,
    DynamicComponentLoaderDirective,
    PropagationClickStopDirective,
    WebviewDirective,
  ],
  imports: [CommonModule, FormsModule, ReactiveFormsModule, TranslateModule],
  exports: [
    TranslateModule,
    DisableControlDirective,
    DynamicComponentLoaderDirective,
    PropagationClickStopDirective,
    WebviewDirective,
    FormsModule,
    ReactiveFormsModule,
  ],
})
export class SharedModule {}
