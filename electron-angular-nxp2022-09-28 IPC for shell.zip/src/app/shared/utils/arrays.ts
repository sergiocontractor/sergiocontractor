/**
 * @description Returns an array as the object
 * @export
 * @param  {any[]} array
 * @param  {(string | number)} key
 * @return object
 */
export function arrayToObject(array: any[], key: string | number): object {
  return array.reduce((data, item) => {
    data[item[key]] = item;
    return data;
  }, {});
}
