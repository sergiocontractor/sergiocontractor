import { NgZone } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { LogLevel } from '../models/global';

export const BENCHMARK_TITLE = 'BENCHMARK';

export class BenchmarkService {
  readonly start = performance.now();

  constructor(
    private readonly logger: any,
    private readonly id: string,
    private readonly ngZone: NgZone,
    private readonly toastrService: ToastrService
  ) {
    this.logger(
      LogLevel.info,
      `BENCHMARK ${this.getTiming()} -> ${this.id} started`
    );
  }

  /**
   * @description Returns current date as Number that represents milliseconds since 1 January 1970 UTC.
   * @return number
   * @memberof BenchmarkService
   */
  getTiming(): number {
    return +new Date();
  }

  /**
   * @description Returns current date as Number that represents milliseconds since 1 January 1970 UTC.
   * @return {void}
   * @memberof BenchmarkService
   */
  stop(): void {
    const time = performance.now() - this.start;
    this.logger(
      LogLevel.info,
      `BENCHMARK ${this.getTiming()} -> ${this.id} finished in ${Math.round(
        time
      )}ms`
    );
    this.ngZone.run(() => {
      this.toastrService.warning(
        `Rendering of boxes took ${Math.round(
          time
        )}ms`,
        BENCHMARK_TITLE
      );
    });
  }
}
