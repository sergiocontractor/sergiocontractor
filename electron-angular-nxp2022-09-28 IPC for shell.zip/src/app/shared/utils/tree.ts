/**
 * @description Tree tag names.
 * @export
 * @enum {number}
 */
export enum TreeTagName {
  Box = 'box',
  Boxes = 'boxes',
  Data = 'data',
  Dataset = 'dataset',
  Datasets = 'datasets',
}

/**
 * @description The level separator character separates levels and ID within the nested tree hierarchy ID.
 */
export const LEVEL_SEPARATOR = '/';

/**
 * @description Box tag names.
 */
export const boxTagNames = [TreeTagName.Box];

/**
 * @description Boxes tag names.
 */
export const boxesTagNames = [TreeTagName.Box, TreeTagName.Boxes];

/**
 * @description Datasets tag name.
 */
export const datasetsTagName = 'datasets';

/**
 * @description Adds a recursive universal ID that can be used to track objects by ID.
 * @export
 * @template T
 * @param  {T} data
 * @param  {number} [id=0]
 * @return *
 */
export function addIdRecursively<T extends any[]>(
  data: T,
  id: number = 0
): any {
  return data?.map(({ tagName, attributes, children, ...rest }) => {
    id++;
    return {
      tagName,
      attributes,
      children: children.length > 1 ? addIdRecursively(children, id) : children,
      uid: id,
      ...rest,
    };
  });
}

/**
 * @descritpiton Returns formatted hierarchical path that includes ID and level.
 * @export
 * @param  {number} id
 * @param  {number} level
 * @return string
 */
export function getHierarchicalPath(id: number, level: number): string {
  return `${level}${LEVEL_SEPARATOR}${id}`;
}

/**
 * @description Returns the parent hierarchical path of the specified node in hierarchicalPath.
 * @export
 * @param  {string} hierarchicalPath
 * @return string
 */
export function getParentHierarchicalPath(hierarchicalPath: string): string {
  const levelIndexes = hierarchicalPath.split(LEVEL_SEPARATOR);
  levelIndexes.pop();
  return levelIndexes.join(LEVEL_SEPARATOR);
}

/**
 * @description Recursive find function to find siblings of a node.
 * @export
 * @param  {Array<any>} array
 * @param  {string} hierarchicalPath
 * @return Array<any>
 */
export function findNodeSiblings(
  array: Array<any>,
  hierarchicalPath: string
): Array<any> {
  let data: any[];
  for (const element of array) {
    if (element.id === hierarchicalPath) {
      data = array;
    } else if (element.children) {
      const siblings = findNodeSiblings(
        element?.children ?? [],
        hierarchicalPath
      );
      if (siblings) {
        data = siblings;
      }
    }
  }
  return data;
}

/**
 * @description Returns true if value has a property tagName, and the tagName is a string value that is included in tagNamesList.
 * @export
 * @param  {string} tagName
 * @param  {string[]} tagNamesList
 * @return boolean
 */
export function isValidTagName(
  tagName: string,
  tagNamesList: string[]
): boolean {
  return (
    tagName && typeof tagName === 'string' && tagNamesList.includes(tagName)
  );
}

/**
 * @description Traverse an array.
 * @export
 * @template T
 * @param  {T} collection
 * @return *
 */
export function traverseArray<T extends any[]>(collection: T): any {
  return collection.map((value) => traverseTree(value));
}

/**
 * @description Traverse an object.
 * @export
 * @template T
 * @param  {T} source
 * @return T
 */
export function traverseObject<T>(source: T): T {
  const result = {} as T;

  Object.keys(source).forEach((key) => {
    const value = source[key as keyof T];
    result[key as keyof T] = traverseTree(value);
  }, {});

  return result as T;
}

/**
 * @description Visiting every node in the tree.
 * @export
 * @template T
 * @param  {T} value
 * @return T
 */
export function traverseTree<T>(value: T): T {
  if (typeof value !== 'object' || value === null) {
    return value;
  }
  if (Array.isArray(value)) {
    return traverseArray(value);
  }
  return traverseObject(value);
}
