export const mockTree = [
  {
    nodeName: 'circuit',
    id: '1/0',
    attributes: {
      type: 'circuit',
      container: '0',
      showcontent: '1',
      expand: '1',
      enabled: '1',
      flags: '',
    },
    children: [],
    datasets: [
      {
        tagName: 'datasets',
        attributes: {},
        children: [
          {
            tagName: 'dataset',
            attributes: {
              name: 'circuit',
            },
            children: [
              {
                tagName: 'data',
                attributes: {
                  name: 'fw',
                  type: 'string',
                },
                children: ['cadence'],
                uid: 3,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'simu',
                  type: 'string',
                },
                children: ['spectre'],
                uid: 4,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'cosimu',
                  type: 'string',
                },
                children: ['none'],
                uid: 5,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'lib',
                  type: 'string',
                },
                children: [],
                uid: 6,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'cell',
                  type: 'string',
                },
                children: [],
                uid: 7,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'view',
                  type: 'string',
                },
                children: [],
                uid: 8,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'path',
                  type: 'string',
                },
                children: ['/dev/null'],
                uid: 9,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'auto',
                  type: 'bool',
                },
                children: ['1'],
                uid: 10,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'linked',
                  type: 'bool',
                },
                children: ['1'],
                uid: 11,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'abvf',
                  type: 'bool',
                },
                children: ['0'],
                uid: 12,
              },
            ],
            uid: 2,
          },
          {
            tagName: 'dataset',
            attributes: {
              name: 'options',
              simu: 'mica',
              cosimu: 'none',
              visible: '0',
            },
            children: [
              {
                tagName: 'data',
                attributes: {
                  name: 'mica.DcvSaveList',
                  type: 'string',
                },
                children: [
                  '{v#* -v#*#* depth=5} {@*#i* *:[0-9]* -@x*.[a-wy-z]*#i* -@x*.[A-WY-Z]*#i* -*#isnoisy depth=5}',
                ],
                uid: 4,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'mica.DcvAutoConverge',
                  type: 'string',
                },
                children: ['auto'],
                uid: 5,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'architecture',
                  type: 'string',
                },
                children: ['-64'],
                uid: 6,
              },
            ],
            uid: 3,
          },
          {
            tagName: 'dataset',
            attributes: {
              name: 'options',
              simu: 'spectre',
              cosimu: 'none',
              visible: '0',
            },
            children: [
              {
                tagName: 'data',
                attributes: {
                  name: 'spectre.DcvSaveList',
                  type: 'string',
                },
                children: ['save=all currents=all subcktprobelvl=5'],
                uid: 5,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'Use_LSF_slots',
                  type: 'string',
                },
                children: ['yes'],
                uid: 6,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'spectreApsOption',
                  type: 'string',
                },
                children: ['+aps'],
                uid: 7,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'spectreMtsOption',
                  type: 'string',
                },
                children: [],
                uid: 8,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'spectreLicOptions',
                  type: 'string',
                },
                children: ['+lqt 0'],
                uid: 9,
              },
            ],
            uid: 4,
          },
          {
            tagName: 'dataset',
            attributes: {
              name: 'models',
              visible: '0',
            },
            children: [
              {
                tagName: 'data',
                attributes: {
                  name: 'useCellSet',
                  type: 'bool',
                },
                children: ['1'],
              },
            ],
            uid: 5,
          },
        ],
        uid: 1,
      },
    ],
  },
  {
    nodeName: 'insert',
    id: '1/1',
    attributes: {
      type: 'insert',
      container: '0',
      showcontent: '1',
      expand: '1',
      enabled: '1',
      flags: '',
    },
    children: [],
    datasets: [
      {
        tagName: 'datasets',
        attributes: {},
        children: [
          {
            tagName: 'dataset',
            attributes: {
              name: 'common',
            },
            children: [
              {
                tagName: 'data',
                attributes: {
                  name: 'report',
                  type: 'string',
                },
                children: ['1'],
                uid: 3,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'comment',
                  type: 'string',
                },
                children: ['non cumulative mode On-the-fly netlist alteration'],
                uid: 4,
              },
            ],
            uid: 2,
          },
          {
            tagName: 'dataset',
            attributes: {
              name: 'line',
              enabled: '1',
            },
            children: [
              {
                tagName: 'data',
                attributes: {
                  name: 'mode',
                  type: 'enum',
                },
                children: ['inb'],
                uid: 4,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'prefix',
                  type: 'string',
                },
                children: [],
                uid: 5,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'name',
                  type: 'string',
                },
                children: ['i%i1'],
                uid: 6,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'name',
                  type: 'text',
                },
                children: [
                  '// BJT ECP Oscillator Comment (indicated by //)&amp;#10;simulator lang=spectre&amp;#10',
                ],
                uid: 7,
              },
            ],
            uid: 3,
          },
          {
            tagName: 'dataset',
            attributes: {
              name: 'line',
              enabled: '1',
            },
            children: [
              {
                tagName: 'data',
                attributes: {
                  name: 'mode',
                  type: 'enum',
                },
                children: ['ic'],
                uid: 5,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'prefix',
                  type: 'string',
                },
                children: [],
                uid: 6,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'name',
                  type: 'string',
                },
                children: ['i%i2'],
                uid: 7,
              },
            ],
            uid: 4,
          },
        ],
        uid: 1,
      },
    ],
  },
  {
    nodeName: 'setvar',
    id: '1/2',
    attributes: {
      type: 'setvar',
      container: '0',
      showcontent: '1',
      expand: '1',
      enabled: '1',
      flags: '',
    },
    children: [],
    datasets: [
      {
        tagName: 'datasets',
        attributes: {},
        children: [
          {
            tagName: 'dataset',
            attributes: {
              name: 'common',
            },
            children: [
              {
                tagName: 'data',
                attributes: {
                  name: 'report',
                  type: 'string',
                },
                children: ['1'],
                uid: 3,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'comment',
                  type: 'string',
                },
                children: ['Parameters or device casing alteration'],
                uid: 4,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'additional',
                  type: 'string',
                },
                children: [
                  'this one is not part of definition, thus shall be ignored / not displayed',
                ],
                uid: 5,
              },
            ],
            uid: 2,
          },
          {
            tagName: 'dataset',
            attributes: {
              name: 'other',
            },
            children: [
              {
                tagName: 'data',
                attributes: {
                  name: 'comment',
                  type: 'string',
                },
                children: [
                  'this one is not part of definition, thus shall be ignored / not displayed',
                ],
              },
            ],
            uid: 3,
          },
          {
            tagName: 'dataset',
            attributes: {
              name: 'line1',
              blockid: 'line',
              enabled: '1',
            },
            children: [
              {
                tagName: 'data',
                attributes: {
                  name: 'mode',
                  type: 'enum',
                },
                children: ['var'],
                uid: 5,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'name',
                  type: 'string',
                },
                children: ['temp'],
                uid: 6,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'value',
                  type: 'expr',
                },
                children: ['27'],
                uid: 7,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'hl',
                  type: 'expr',
                },
                children: ['1'],
                uid: 8,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'll',
                  type: 'expr',
                },
                children: ['0'],
                uid: 9,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'coding',
                  type: 'enum',
                },
                children: ['binary'],
                uid: 10,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'dummy',
                  type: 'string',
                },
                children: [
                  'this one is not part of definition, thus shall be ignored / not displayed',
                ],
                uid: 11,
              },
            ],
            uid: 4,
          },
          {
            tagName: 'dataset',
            attributes: {
              name: 'line2',
              blockid: 'line',
              enabled: '1',
            },
            children: [
              {
                tagName: 'data',
                attributes: {
                  name: 'mode',
                  type: 'enum',
                },
                children: ['var'],
                uid: 6,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'name',
                  type: 'string',
                },
                children: ['temp'],
                uid: 7,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'value',
                  type: 'expr',
                },
                children: ['27'],
                uid: 8,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'hl',
                  type: 'expr',
                },
                children: ['1'],
                uid: 9,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'll',
                  type: 'expr',
                },
                children: ['0'],
                uid: 10,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'coding',
                  type: 'enum',
                },
                children: ['binary'],
                uid: 11,
              },
            ],
            uid: 5,
          },
        ],
        uid: 1,
      },
    ],
  },
  {
    nodeName: 'loop',
    id: '1/3',
    attributes: {
      type: 'loop',
      container: '1',
      showcontent: '1',
      expand: '1',
      enabled: '1',
      flags: 'dist 1',
    },
    children: [
      {
        nodeName: 'analysis',
        id: '1/3/0',
        attributes: {
          type: 'analysis',
          container: '1',
          showcontent: '0',
          expand: '1',
          enabled: '1',
          flags: 'work 1',
        },
        children: [],
        datasets: [
          {
            tagName: 'datasets',
            attributes: {},
            children: [
              {
                tagName: 'dataset',
                attributes: {
                  name: 'general',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'mode',
                      type: 'string',
                    },
                    children: ['TRAN'],
                  },
                ],
                uid: 2,
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'control',
                  mode: 'TRAN',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'clk_opt',
                      type: 'string',
                    },
                    children: ['OFF'],
                    uid: 4,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'errpreset',
                      type: 'string',
                    },
                    children: ['none'],
                    uid: 5,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'dynamic_params',
                      type: 'string',
                    },
                    children: ['OFF'],
                    uid: 6,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'stepControl',
                      type: 'string',
                    },
                    children: ['autostep'],
                    uid: 7,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'sample',
                      type: 'string',
                    },
                    children: ['5n'],
                    uid: 8,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'start',
                      type: 'string',
                    },
                    children: [],
                    uid: 9,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'stop',
                      type: 'string',
                    },
                    children: ['80u'],
                    uid: 10,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'tranNoise',
                      type: 'string',
                    },
                    children: ['OFF'],
                    uid: 11,
                  },
                ],
                uid: 3,
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'mica none,TRAN',
                  visible: '1',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'tstep',
                      type: 'string',
                    },
                    children: ['100p'],
                    uid: 5,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'PreAnalysisCommand',
                      type: 'string',
                    },
                    children: ['save all depth=3'],
                    uid: 6,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'tmax',
                      type: 'string',
                    },
                    children: ['10n'],
                    uid: 7,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'AllowMarchingPlot',
                      type: 'string',
                    },
                    children: ['no'],
                    uid: 8,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'sourceonly',
                      type: 'string',
                    },
                    children: ['no'],
                    uid: 9,
                  },
                ],
                uid: 4,
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'VCSMica none,TRAN',
                  visible: '0',
                },
                children: [],
                uid: 5,
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'spectre none,TRAN',
                  visible: '0',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'annotate',
                      type: 'string',
                    },
                    children: ['status'],
                    uid: 7,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'fastbreak',
                      type: 'string',
                    },
                    children: ['no'],
                    uid: 8,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'ic',
                      type: 'string',
                    },
                    children: ['all'],
                    uid: 9,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'maxiters',
                      type: 'string',
                    },
                    children: ['5'],
                    uid: 10,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'ckptperiod',
                      type: 'string',
                    },
                    children: ['1800'],
                    uid: 11,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'annotateic',
                      type: 'string',
                    },
                    children: ['no'],
                    uid: 12,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'cmin',
                      type: 'string',
                    },
                    children: ['0'],
                    uid: 13,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'd2aminstep',
                      type: 'string',
                    },
                    children: ['0'],
                    uid: 14,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'fastcross',
                      type: 'string',
                    },
                    children: ['discrete'],
                    uid: 15,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'maxstep',
                      type: 'string',
                    },
                    children: ['5n'],
                    uid: 16,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'restart',
                      type: 'string',
                    },
                    children: ['yes'],
                    uid: 17,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'skipdc',
                      type: 'string',
                    },
                    children: ['no'],
                    uid: 18,
                  },
                ],
                uid: 6,
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'options',
                  visible: '0',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'COMPAREMODE',
                      type: 'enum',
                    },
                    children: ['default'],
                    uid: 8,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'method',
                      type: 'string',
                      enabled: '1',
                    },
                    children: ['gear2only'],
                    uid: 9,
                  },
                ],
                uid: 7,
              },
            ],
            uid: 1,
          },
        ],
      },
      {
        nodeName: 'meas:clip',
        id: '1/3/1',
        attributes: {
          type: 'meas:clip',
          container: '0',
          showcontent: '1',
          expand: '1',
          enabled: '1',
          flags: '',
        },
        children: [],
        datasets: [
          {
            tagName: 'datasets',
            attributes: {},
            children: [
              {
                tagName: 'dataset',
                attributes: {
                  name: 'clip',
                  enabled: '1',
                  report: '0',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'name',
                      type: 'string',
                    },
                    children: ['clipped'],
                    uid: 3,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'unit',
                      type: 'enum',
                    },
                    children: [],
                    uid: 4,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'dim',
                      type: 'enum',
                    },
                    children: ['vector'],
                    uid: 5,
                  },
                ],
                uid: 2,
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'common',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'signal',
                      type: 'expr',
                    },
                    children: ['v(v#out)'],
                    uid: 4,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'from',
                      type: 'expr',
                    },
                    children: ['31u'],
                    uid: 5,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'to',
                      type: 'expr',
                    },
                    children: ['32u'],
                    uid: 6,
                  },
                ],
                uid: 3,
              },
            ],
            uid: 1,
          },
        ],
      },
      {
        nodeName: 'meas:crossing',
        id: '1/3/2',
        attributes: {
          type: 'meas:crossing',
          container: '0',
          showcontent: '1',
          expand: '1',
          enabled: '1',
          flags: '',
        },
        children: [],
        datasets: [
          {
            tagName: 'datasets',
            attributes: {},
            children: [
              {
                tagName: 'dataset',
                attributes: {
                  name: 'crossing',
                  enabled: '1',
                  report: '0',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'name',
                      type: 'string',
                    },
                    children: ['outcrossings'],
                    uid: 3,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'unit',
                      type: 'enum',
                    },
                    children: [],
                    uid: 4,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'dim',
                      type: 'enum',
                    },
                    children: ['vector'],
                    uid: 5,
                  },
                ],
                uid: 2,
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'common',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'signal1',
                      type: 'expr',
                    },
                    children: ['clipped'],
                    uid: 4,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'signal2',
                      type: 'expr',
                    },
                    children: ['10'],
                    uid: 5,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'xy',
                      type: 'expr',
                    },
                    children: [],
                    uid: 6,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'nbcross',
                      type: 'expr',
                    },
                    children: ['1'],
                    uid: 7,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'crossType',
                      type: 'expr',
                    },
                    children: ['1'],
                    uid: 8,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'delay',
                      type: 'expr',
                    },
                    children: [],
                    uid: 9,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'multiple',
                      type: 'expr',
                    },
                    children: ['1'],
                    uid: 10,
                  },
                ],
                uid: 3,
              },
            ],
            uid: 1,
          },
        ],
      },
      {
        nodeName: 'meas:custom',
        id: '1/3/3',
        attributes: {
          type: 'meas:custom',
          container: '0',
          showcontent: '1',
          expand: '1',
          enabled: '1',
          flags: '',
        },
        children: [],
        datasets: [
          {
            tagName: 'datasets',
            attributes: {},
            children: [
              {
                tagName: 'dataset',
                attributes: {
                  name: 'custom',
                  enabled: '1',
                  report: '1',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'name',
                      type: 'string',
                    },
                    children: ['xnb'],
                    uid: 3,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'unit',
                      type: 'enum',
                    },
                    children: [],
                    uid: 4,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'dim',
                      type: 'enum',
                    },
                    children: ['vector'],
                    uid: 5,
                  },
                ],
                uid: 2,
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'common',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'signal',
                      type: 'expr',
                    },
                    children: ['count(outcrossings)'],
                    uid: 4,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'versus',
                      type: 'expr',
                    },
                    children: ['0'],
                    uid: 5,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'versusid',
                      type: 'expr',
                    },
                    children: [],
                    uid: 6,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'comment',
                      type: 'expr',
                    },
                    children: [],
                    uid: 7,
                  },
                ],
                uid: 3,
              },
            ],
            uid: 1,
          },
        ],
      },
      {
        nodeName: 'meas:custom',
        id: '1/3/4',
        attributes: {
          type: 'meas:custom',
          container: '0',
          showcontent: '1',
          expand: '1',
          enabled: '1',
          flags: '',
        },
        children: [],
        datasets: [
          {
            tagName: 'datasets',
            attributes: {},
            children: [
              {
                tagName: 'dataset',
                attributes: {
                  name: 'custom',
                  enabled: '1',
                  report: '1',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'name',
                      type: 'string',
                    },
                    children: ['xnb2'],
                    uid: 3,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'unit',
                      type: 'enum',
                    },
                    children: [],
                    uid: 4,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'dim',
                      type: 'enum',
                    },
                    children: ['vector'],
                    uid: 5,
                  },
                ],
                uid: 2,
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'common',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'signal',
                      type: 'expr',
                    },
                    children: ['count(cross(clip(v(v#out),31u,32u'],
                    uid: 4,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'versus',
                      type: 'expr',
                    },
                    children: ['0'],
                    uid: 5,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'versusid',
                      type: 'expr',
                    },
                    children: [],
                    uid: 6,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'comment',
                      type: 'expr',
                    },
                    children: [],
                    uid: 7,
                  },
                ],
                uid: 3,
              },
            ],
            uid: 1,
          },
        ],
      },
      {
        nodeName: 'plot',
        id: '1/3/5',
        attributes: {
          type: 'plot',
          container: '0',
          showcontent: '1',
          expand: '0',
          enabled: '1',
          flags: '',
        },
        children: [],
        datasets: [
          {
            tagName: 'datasets',
            attributes: {},
            children: [
              {
                tagName: 'dataset',
                attributes: {
                  name: 'general',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'type',
                      type: 'enum',
                    },
                    children: ['type line'],
                    uid: 3,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'linkid',
                      type: 'expr',
                    },
                    children: [],
                    uid: 4,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'id',
                      type: 'string',
                    },
                    children: ['plot1'],
                    uid: 5,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'tool',
                      type: 'string',
                    },
                    children: ['mica'],
                    uid: 6,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'tool',
                      type: 'enum',
                    },
                    children: ['auto'],
                    uid: 7,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'display',
                      type: 'bool',
                    },
                    children: ['1'],
                    uid: 8,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'title',
                      type: 'string',
                    },
                    children: [],
                    uid: 9,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'linkmode',
                      type: 'enum',
                    },
                    children: ['noSpec'],
                    uid: 10,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'report',
                      type: 'bool',
                    },
                    children: ['0'],
                    uid: 11,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'mode',
                      type: 'enum',
                    },
                    children: ['xygrouped'],
                    uid: 12,
                  },
                ],
                uid: 2,
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'y1-line',
                  enabled: '1',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'log',
                      type: 'enum',
                    },
                    children: ['lin'],
                    uid: 4,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'label',
                      type: 'string',
                    },
                    children: [],
                    uid: 5,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'expr',
                      type: 'expr',
                    },
                    children: ['v(/out)'],
                    uid: 6,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'col',
                      type: 'string',
                    },
                    children: ['auto'],
                    uid: 7,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'symb',
                      type: 'string',
                    },
                    children: [],
                    uid: 8,
                  },
                ],
                uid: 3,
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'y2-line',
                  enabled: '1',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'log',
                      type: 'enum',
                    },
                    children: ['lin'],
                    uid: 5,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'label',
                      type: 'string',
                    },
                    children: [],
                    uid: 6,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'expr',
                      type: 'expr',
                    },
                    children: ['v(v#out)'],
                    uid: 7,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'col',
                      type: 'string',
                    },
                    children: ['auto'],
                    uid: 8,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'symb',
                      type: 'string',
                    },
                    children: [],
                    uid: 9,
                  },
                ],
                uid: 4,
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'options',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'grid',
                      type: 'string',
                    },
                    children: ['none'],
                    uid: 6,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'bw',
                      type: 'string',
                    },
                    children: ['0'],
                    uid: 7,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'dash',
                      type: 'string',
                    },
                    children: ['0'],
                    uid: 8,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'legend',
                      type: 'string',
                    },
                    children: ['1'],
                    uid: 9,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'linewidth',
                      type: 'string',
                    },
                    children: ['0'],
                    uid: 10,
                  },
                ],
                uid: 5,
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'x-line',
                  enabled: '1',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'log',
                      type: 'enum',
                    },
                    children: ['lin'],
                    uid: 7,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'label',
                      type: 'string',
                    },
                    children: [],
                    uid: 8,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'expr',
                      type: 'expr',
                    },
                    children: [],
                    uid: 9,
                  },
                ],
                uid: 6,
              },
            ],
            uid: 1,
          },
        ],
      },
      {
        nodeName: 'meas:atx',
        id: '1/3/6',
        attributes: {
          type: 'meas:atx',
          container: '0',
          showcontent: '1',
          expand: '1',
          enabled: '1',
          flags: '',
        },
        children: [],
        datasets: [
          {
            tagName: 'datasets',
            attributes: {},
            children: [
              {
                tagName: 'dataset',
                attributes: {
                  name: 'atx',
                  enabled: '1',
                  report: '1',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'name',
                      type: 'string',
                    },
                    children: ['atx_25u'],
                    uid: 3,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'unit',
                      type: 'enum',
                    },
                    children: [],
                    uid: 4,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'dim',
                      type: 'enum',
                    },
                    children: ['vector'],
                    uid: 5,
                  },
                ],
                uid: 2,
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'common',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'signal',
                      type: 'expr',
                    },
                    children: ['v(v#out)'],
                    uid: 4,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'x',
                      type: 'expr',
                    },
                    children: ['25u'],
                    uid: 5,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'period',
                      type: 'expr',
                    },
                    children: [],
                    uid: 6,
                  },
                ],
                uid: 3,
              },
            ],
            uid: 1,
          },
        ],
      },
      {
        nodeName: 'meas:aty',
        id: '1/3/7',
        attributes: {
          type: 'meas:aty',
          container: '0',
          showcontent: '1',
          expand: '1',
          enabled: '1',
          flags: '',
        },
        children: [],
        datasets: [
          {
            tagName: 'datasets',
            attributes: {},
            children: [
              {
                tagName: 'dataset',
                attributes: {
                  name: 'aty',
                  enabled: '1',
                  report: '1',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'name',
                      type: 'string',
                    },
                    children: ['trig'],
                    uid: 3,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'unit',
                      type: 'enum',
                    },
                    children: [],
                    uid: 4,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'dim',
                      type: 'enum',
                    },
                    children: ['vector'],
                    uid: 5,
                  },
                ],
                uid: 2,
              },
              {
                tagName: 'dataset',
                attributes: {
                  name: 'common',
                },
                children: [
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'signal',
                      type: 'expr',
                    },
                    children: ['v(v#out)'],
                    uid: 4,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'threshold',
                      type: 'expr',
                    },
                    children: ['2.5'],
                    uid: 5,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'nbcross',
                      type: 'expr',
                    },
                    children: ['1'],
                    uid: 6,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'crossType',
                      type: 'expr',
                    },
                    children: ['0'],
                    uid: 7,
                  },
                  {
                    tagName: 'data',
                    attributes: {
                      name: 'delay',
                      type: 'expr',
                    },
                    children: [],
                    uid: 8,
                  },
                ],
                uid: 3,
              },
            ],
            uid: 1,
          },
        ],
      },
    ],
    datasets: [
      {
        tagName: 'datasets',
        attributes: {},
        children: [
          {
            tagName: 'dataset',
            attributes: {
              name: 'common',
            },
            children: [
              {
                tagName: 'data',
                attributes: {
                  name: 'comment',
                  type: 'string',
                },
                children: ['Loop over variables or device cases'],
              },
            ],
            uid: 2,
          },
          {
            tagName: 'dataset',
            attributes: {
              name: 'line1',
              blockid: 'line',
              enabled: '1',
            },
            children: [
              {
                tagName: 'data',
                attributes: {
                  name: 'mode',
                  type: 'enum',
                },
                children: ['var'],
                uid: 4,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'name',
                  type: 'expr',
                },
                children: ['toto'],
                uid: 5,
              },
              {
                tagName: 'data',
                attributes: {
                  name: 'inc',
                  type: 'expr',
                },
                children: ['1 2 3'],
                uid: 6,
              },
            ],
            uid: 3,
          },
        ],
        uid: 1,
      },
    ],
  },
];
