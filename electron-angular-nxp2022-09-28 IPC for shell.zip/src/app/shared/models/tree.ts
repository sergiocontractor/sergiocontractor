import { PrimitivesType } from './global';
import { XMLNode } from './nodes';

export type TreeNodeAttributes = Record<string, PrimitivesType>;

export interface XMLNodeUid extends XMLNode {
  uid: number;
}

/**
 * Data node with nested structure.
 * Each node has a tagName that equals to value "box", and a type casted as nodeName.
 */
export class TreeNode {
  id: string;
  nodeName: string;
  attributes: TreeNodeAttributes;
  children: TreeNode[];
  datasets: XMLNodeUid[];
  tagName?: string;
}

/** Flat node with expandable and level information */
export class TreeFlatNode {
  constructor(
    public id: string,
    public nodeName: string,
    public attributes: TreeNodeAttributes,
    public datasets: XMLNodeUid[],
    public expandable: boolean,
    public level: number
  ) {}
}
