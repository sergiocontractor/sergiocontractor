import { TreeNodeAttributes } from './tree';

export interface XMLNode {
  tagName: string;
  attributes: TreeNodeAttributes;
  children: XMLNodeList;
}

export type XMLNodeList = Array<XMLNode | string>;
