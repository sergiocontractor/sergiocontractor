import { PropagationClickStopDirective } from './propagation-stop.directive';

describe('PropagationClickStopDirective ', () => {
  it('should create an instance', () => {
    const directive = new PropagationClickStopDirective();
    expect(directive).toBeTruthy();
  });
});
