import { Directive, HostListener } from '@angular/core';

@Directive({
  selector: '[propagationClickStop]',
})
export class PropagationClickStopDirective {
  @HostListener('click', ['$event'])
  public onClick(event: MouseEvent): void {
    event.stopPropagation();
  }
}
