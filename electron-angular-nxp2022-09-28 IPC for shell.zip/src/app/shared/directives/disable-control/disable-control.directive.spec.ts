import { DisableControlDirective } from './disable-control.directive';

describe('DisableControlDirective ', () => {
  it('should create an instance', () => {
    const directive = new DisableControlDirective(null);
    expect(directive).toBeTruthy();
  });
});
